

import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import { ProductList } from './components/ProductGrid';
import { useListings } from './hooks/useListings';
import { Product, User, CartItem, GameCategory, NotificationData } from './types';
import { ProductDetailModal } from './components/ProductDetailModal';
import { SignInModal } from './components/SignInModal';
import { SignUpModal } from './components/SignUpModal';
import { CheckoutPage } from './components/CheckoutPage';
import { OrderConfirmationPage } from './components/OrderConfirmationPage';
import { CartSidebar } from './components/CartSidebar';
import { useTranslation } from 'react-i18next';
import { FaqSection } from './components/FaqSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { AdminPanel } from './components/AdminPanel';
import { CryptoPaymentModal } from './components/CryptoPaymentModal';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import Spinner from './components/Spinner';
import { RecentPurchaseToast } from './components/RecentPurchaseToast';

const ADMIN_EMAILS = ['admin@vairis.io'];

const LOCATIONS = [
  'Hamburg, Germany',
  'Tokyo, Japan',
  'Los Angeles, USA',
  'London, UK',
  'Sydney, Australia',
  'Paris, France',
  'Seoul, South Korea',
  'Toronto, Canada'
];


// IMPORTANT: This key must be set in the environment variables.
// The build system must replace process.env.STRIPE_PUBLISHABLE_KEY.
const stripePromise = loadStripe(process.env.STRIPE_PUBLISHABLE_KEY!);

const App: React.FC = () => {
  const { t } = useTranslation();
  const { products, addProduct, updateProduct, deleteProduct, categories, addCategory, updateCategory, deleteCategory } = useListings();
  const [view, setView] = useState<'listings' | 'checkout' | 'confirmation' | 'admin'>('listings');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  // Search State
  const [searchTerm, setSearchTerm] = useState('');

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutItems, setCheckoutItems] = useState<CartItem[]>([]);
  const [finalDiscount, setFinalDiscount] = useState(0);

  // Auth State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Modal State
  const [showSignInModal, setShowSignInModal] = useState(false);
  const [showSignUpModal, setShowSignUpModal] = useState(false);
  const [isCryptoModalOpen, setIsCryptoModalOpen] = useState(false);
  const [cryptoCheckoutInfo, setCryptoCheckoutInfo] = useState<{items: CartItem[], discount: number} | null>(null);

  // Notification State
  const [notification, setNotification] = useState<NotificationData | null>(null);

  // Theme State
  const [theme, setTheme] = useState('indigo');

  // Stripe State
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    const themes = ['theme-indigo', 'theme-yellow', 'theme-light'];
    root.classList.remove(...themes);
    root.classList.add(`theme-${theme}`);
  }, [theme]);

  const stripeOptions = useMemo(() => {
    if (!clientSecret) {
      return undefined;
    }
    return {
      clientSecret,
      appearance: {
        theme: 'night' as const,
        labels: 'floating' as const,
      },
    };
  }, [clientSecret]);

  const displayedProducts = useMemo(() => {
    if (!selectedCategory) return [];
    
    let prods = products.filter(p => p.category === selectedCategory);

    if (searchTerm) {
      const lowercasedTerm = searchTerm.toLowerCase();
      prods = prods.filter(p => 
        p.name.toLowerCase().includes(lowercasedTerm) ||
        p.description.toLowerCase().includes(lowercasedTerm)
      );
    }

    return prods;
  }, [products, selectedCategory, searchTerm]);

  const displayedCategories = useMemo(() => {
    if (selectedCategory) return [];

    let cats = categories;

    if (searchTerm) {
        const lowercasedTerm = searchTerm.toLowerCase();
        cats = cats.filter(c => 
            c.name.toLowerCase().includes(lowercasedTerm)
        );
    }
    return cats;
  }, [selectedCategory, categories, searchTerm]);

  const handleSelectCategory = useCallback((categoryName: string) => {
    setSelectedCategory(categoryName);
    window.scrollTo(0, 0);
  }, []);

  const handleBackToCategories = useCallback(() => {
    setSelectedCategory(null);
  }, []);

  const handleSelectProduct = useCallback((product: Product) => {
    setSelectedProduct(product);
    window.scrollTo(0, 0);
  }, []);

  const handleCloseDetailModal = useCallback(() => {
    setSelectedProduct(null);
  }, []);
  
  const handleAddToCart = useCallback((product: Product, quantity: number) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prevCart, { ...product, quantity }];
    });
    setIsCartOpen(true);
  }, []);

  const handleUpdateCartQuantity = useCallback((productId: string, quantity: number) => {
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === productId ? { ...item, quantity } : item
      ).filter(item => item.quantity > 0)
    );
  }, []);
  
  const handleRemoveFromCart = useCallback((productId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== productId));
  }, []);

  const startCheckout = useCallback((items: CartItem[]) => {
    if (!isLoggedIn) {
      handleOpenSignIn();
      return;
    }
    
    // --- SIMULATE SERVER-SIDE PAYMENT INTENT CREATION ---
    // In a real app, you would make a fetch request to your server here.
    // The server would create a PaymentIntent with the amount and return its client_secret.
    const amount = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    console.log(`Simulating creating a Stripe Payment Intent for $${amount.toFixed(2)}`);
    // This is a fake client secret for demonstration purposes.
    // It's structured like a real one but will not work with Stripe's APIs.
    const mockClientSecret = `pi_${Date.now()}_secret_${Math.random().toString(36).substring(2)}`;
    setClientSecret(mockClientSecret);
    // --- END SIMULATION ---

    setCheckoutItems(items);
    setView('checkout');
    window.scrollTo(0, 0);
  }, [isLoggedIn]);

  const handleProceedToCheckout = useCallback(() => {
    if (cart.length > 0) {
      startCheckout(cart);
      setIsCartOpen(false);
    }
  }, [cart, startCheckout]);

  const handleBuyNow = useCallback((product: Product, quantity: number) => {
      startCheckout([{...product, quantity}]);
      setSelectedProduct(null); // Close modal
  }, [startCheckout]);

  const handlePaymentComplete = useCallback((paidItems: CartItem[], discount: number) => {
    setCheckoutItems(paidItems); // these are now the purchased items
    setFinalDiscount(discount);
    setCart(prevCart => prevCart.filter(cartItem => !paidItems.find(paidItem => paidItem.id === cartItem.id)));
    setView('confirmation');
    window.scrollTo(0, 0);
  }, []);
  
  const handleReturnToHome = useCallback(() => {
    setSelectedProduct(null);
    setCheckoutItems([]);
    setFinalDiscount(0);
    setView('listings');
    setSelectedCategory(null);
    setClientSecret(null);
    setSearchTerm('');
    window.scrollTo(0, 0);
  }, []);
  
  const closeModals = () => {
    setShowSignInModal(false);
    setShowSignUpModal(false);
    setIsCryptoModalOpen(false);
  };

  const handleOpenSignIn = () => {
    closeModals();
    setShowSignInModal(true);
  };
  
  const handleOpenSignUp = () => {
    closeModals();
    setShowSignUpModal(true);
  };

  const handleSignIn = (user: User) => {
    const isAdmin = ADMIN_EMAILS.includes(user.email.toLowerCase());
    setIsLoggedIn(true);
    setCurrentUser({ ...user, isAdmin });
    closeModals();
  };

  const handleSignUp = (user: User) => {
    setIsLoggedIn(true);
    setCurrentUser({ ...user, isAdmin: false }); // New users are not admins
    closeModals();
    alert(`Welcome, ${user.email}! Your account has been created.`);
  };

  const handleSignOut = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    if(view === 'checkout' || view === 'confirmation' || view === 'admin') {
      handleReturnToHome();
    }
  };

  const handleAuthRequest = () => {
    handleOpenSignIn();
  };

  const handleNavigateToAdmin = useCallback(() => {
    if (currentUser?.isAdmin) {
      setView('admin');
      window.scrollTo(0, 0);
    }
  }, [currentUser]);

  const handleBackFromCheckout = useCallback(() => {
    setView('listings');
    setCheckoutItems([]);
    setClientSecret(null);
  }, []);
  
  const handleCryptoPayRequest = useCallback((items: CartItem[], discount: number) => {
      setCryptoCheckoutInfo({ items, discount });
      setIsCryptoModalOpen(true);
  }, []);
  
  const handleCompleteCryptoPayment = useCallback(() => {
      if (cryptoCheckoutInfo) {
          handlePaymentComplete(cryptoCheckoutInfo.items, cryptoCheckoutInfo.discount);
      }
      setIsCryptoModalOpen(false);
  }, [cryptoCheckoutInfo, handlePaymentComplete]);
  
  // --- Purchase Notification Logic ---
  useEffect(() => {
    const isModalOpen = !!(selectedProduct || showSignInModal || showSignUpModal || isCartOpen || view !== 'listings' || isCryptoModalOpen);
  
    // Don't schedule new notifications if a modal is open, a notification is already showing, or there are no products.
    if (isModalOpen || notification || products.length === 0 || document.hidden) {
      return;
    }
  
    let timeoutId: number;
  
    const showNotification = () => {
      const randomProduct = products[Math.floor(Math.random() * products.length)];
      const randomLocation = LOCATIONS[Math.floor(Math.random() * LOCATIONS.length)];
  
      setNotification({
        productName: randomProduct.name,
        imageUrl: randomProduct.imageUrl,
        location: randomLocation,
        timestamp: new Date(),
      });
    };
  
    // Schedule the next notification at a random interval
    const delay = Math.random() * 8000 + 7000; // 7-15 seconds
    timeoutId = window.setTimeout(showNotification, delay);
  
    return () => clearTimeout(timeoutId);
  
  }, [notification, products, selectedProduct, showSignInModal, showSignUpModal, isCartOpen, view, isCryptoModalOpen]);

  // Effect to automatically hide the notification after a delay
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000); // Display for 5 seconds
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const cartItemCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);

  const renderContent = () => {
    if (view === 'admin' && currentUser?.isAdmin) {
      return (
        <AdminPanel
          products={products}
          onAddProduct={addProduct}
          onUpdateProduct={updateProduct}
          onDeleteProduct={deleteProduct}
          categories={categories}
          onAddCategory={addCategory}
          onUpdateCategory={updateCategory}
          onDeleteCategory={deleteCategory}
          onExitAdmin={handleReturnToHome}
        />
      );
    }
    if (view === 'confirmation' && checkoutItems.length > 0) {
      return <OrderConfirmationPage purchasedItems={checkoutItems} discount={finalDiscount} onReturnHome={handleReturnToHome} />;
    }
    if (view === 'checkout' && checkoutItems.length > 0) {
      if (!stripePromise || !stripeOptions) {
        return <div className="w-full h-screen flex items-center justify-center"><Spinner size="lg"/></div>;
      }
      return (
        <Elements stripe={stripePromise} options={stripeOptions}>
            <CheckoutPage 
                cartItems={checkoutItems} 
                onConfirmPayment={handlePaymentComplete} 
                onBack={handleBackFromCheckout} 
                onCryptoPayRequest={handleCryptoPayRequest} 
            />
        </Elements>
      );
    }
    
    // Main listings view
    return (
      <>
        {!selectedCategory && !searchTerm && <Hero onSignUp={handleOpenSignUp} />}
        <div id="products-section" className="container mx-auto px-6 mt-16 scroll-mt-24">
          <ProductList
            products={displayedProducts}
            categories={displayedCategories}
            selectedCategory={selectedCategory}
            onSelectCategory={handleSelectCategory}
            onSelectProduct={handleSelectProduct}
            onBack={handleBackToCategories}
          />
        </div>
        {!selectedCategory && <TestimonialsSection />}
        {!selectedCategory && <FaqSection />}
      </>
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-brand-primary">
      <div className="fixed inset-0 z-0 bg-grid-pattern">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,_rgba(79,70,229,0.15)_0%,_rgba(79,70,229,0)_35%)]"></div>
      </div>

      <div className="relative z-10 flex flex-col flex-grow">
        <Header 
          isLoggedIn={isLoggedIn}
          currentUser={currentUser}
          onSignIn={handleOpenSignIn}
          onSignUp={handleOpenSignUp}
          onSignOut={handleSignOut}
          cartItemCount={cartItemCount}
          onCartClick={() => setIsCartOpen(true)}
          searchTerm={searchTerm}
          onSearchChange={setSearchTerm}
          theme={theme}
          setTheme={setTheme}
        />
        <main className="flex-grow">
          {renderContent()}
        </main>
        <Footer onNavigateToAdmin={handleNavigateToAdmin} isAdmin={!!currentUser?.isAdmin} />
      </div>

      <CartSidebar 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onRemoveItem={handleRemoveFromCart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onCheckout={handleProceedToCheckout}
      />

      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={handleCloseDetailModal}
          isLoggedIn={isLoggedIn}
          onRequestAuth={handleAuthRequest}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
        />
      )}

      {showSignInModal && (
        <SignInModal
          onClose={closeModals}
          onSignIn={handleSignIn}
          onSwitchToSignUp={handleOpenSignUp}
        />
      )}

      {showSignUpModal && (
        <SignUpModal
          onClose={closeModals}
          onSignUp={handleSignUp}
          onSwitchToSignIn={handleOpenSignIn}
        />
      )}
      
      {isCryptoModalOpen && cryptoCheckoutInfo && (
        <CryptoPaymentModal
            isOpen={isCryptoModalOpen}
            onClose={() => setIsCryptoModalOpen(false)}
            totalPrice={cryptoCheckoutInfo.items.reduce((sum, i) => sum + i.price * i.quantity, 0) - cryptoCheckoutInfo.discount}
            onConfirm={handleCompleteCryptoPayment}
        />
      )}
      
      {notification && <RecentPurchaseToast notification={notification} />}

      <a
        href="https://discord.gg/Vairis"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Join our Discord server"
        className="fixed bottom-6 right-6 z-40 w-16 h-16 rounded-full hover:scale-105 transition-all duration-300 shadow-lg"
      >
        <img src="https://pbs.twimg.com/profile_images/1796082052703436801/9cOn5C3M_400x400.jpg" alt="Join our Discord server" className="w-full h-full rounded-full object-cover" />
      </a>
    </div>
  );
};

export default App;