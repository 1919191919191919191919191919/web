import React, { useState } from 'react';
import { Product, GameTemplate, GameCategory } from '../types';
import { useTranslation } from 'react-i18next';
import { Icon, ArrowLeftIcon, PlusIcon } from './Icon';
import { ProductFormModal } from './ProductFormModal';
import { CategoryFormModal } from './CategoryFormModal';
import { GameTemplateSelectorModal } from './GameTemplateSelectorModal';

interface AdminPanelProps {
  products: Product[];
  onAddProduct: (productData: Omit<Product, 'id' | 'seller' | 'rating' | 'reviews'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  
  categories: GameCategory[];
  onAddCategory: (categoryData: Omit<GameCategory, 'id'>) => void;
  onUpdateCategory: (category: GameCategory) => void;
  onDeleteCategory: (categoryId: string) => void;

  onExitAdmin: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ 
  products, onAddProduct, onUpdateProduct, onDeleteProduct, 
  categories, onAddCategory, onUpdateCategory, onDeleteCategory, 
  onExitAdmin 
}) => {
  const { t } = useTranslation();
  
  // Product Modals State
  const [isTemplateSelectorOpen, setIsTemplateSelectorOpen] = useState(false);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Partial<Product> | null>(null);

  // Category Modal State
  const [isCategoryFormOpen, setIsCategoryFormOpen] = useState(false);
  const [categoryToEdit, setCategoryToEdit] = useState<GameCategory | null>(null);


  // --- Product Functions ---
  const handleOpenAddProductFlow = () => {
    setProductToEdit(null);
    setIsTemplateSelectorOpen(true);
  };

  const closeProductForm = () => {
    setIsProductFormOpen(false);
    setProductToEdit(null);
  };

  const handleTemplateSelect = (template: GameTemplate | null) => {
    setIsTemplateSelectorOpen(false);
    setProductToEdit(template ? { ...template, category: template.name } : null);
    setIsProductFormOpen(true);
  };

  const handleEditProductClick = (product: Product) => {
    setProductToEdit(product);
    setIsProductFormOpen(true);
  };

  const handleSaveProduct = (productData: Omit<Product, 'id' | 'seller' | 'rating' | 'reviews'> | Product) => {
    if ('id' in productData) {
      onUpdateProduct(productData as Product);
    } else {
      onAddProduct(productData as Omit<Product, 'id' | 'seller' | 'rating' | 'reviews'>);
    }
    closeProductForm();
  };

  const handleDeleteProduct = (productId: string) => {
    if (window.confirm(t('admin.deleteConfirm'))) {
      onDeleteProduct(productId);
    }
  };

  // --- Category Functions ---
  const handleOpenAddCategory = () => {
    setCategoryToEdit(null);
    setIsCategoryFormOpen(true);
  };

  const handleEditCategoryClick = (category: GameCategory) => {
    setCategoryToEdit(category);
    setIsCategoryFormOpen(true);
  };

  const closeCategoryForm = () => {
      setIsCategoryFormOpen(false);
      setCategoryToEdit(null);
  };

  const handleSaveCategory = (categoryData: Omit<GameCategory, 'id'> | GameCategory) => {
    if ('id' in categoryData) {
      onUpdateCategory(categoryData as GameCategory);
    } else {
      onAddCategory(categoryData as Omit<GameCategory, 'id'>);
    }
    closeCategoryForm();
  };

  const handleDeleteCategory = (categoryId: string) => {
    if (window.confirm(t('admin.deleteCategoryConfirm'))) {
        onDeleteCategory(categoryId);
    }
  };

  return (
    <>
      <div className="container mx-auto px-6 py-12 animate-fade-in-up opacity-0">
        <div className="flex justify-between items-center mb-10">
          <h1 className="text-4xl font-extrabold text-brand-text tracking-tight">{t('admin.title')}</h1>
          <button onClick={onExitAdmin} className="flex items-center space-x-2 text-brand-text-secondary hover:text-brand-text transition-colors group">
            <Icon icon={ArrowLeftIcon} className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
            <span>{t('admin.exit')}</span>
          </button>
        </div>

        {/* Products Section */}
        <section className="mb-16">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-brand-text">{t('admin.products')}</h2>
            <button onClick={handleOpenAddProductFlow} className="flex items-center space-x-2 bg-brand-accent text-brand-text-on-accent font-semibold py-2 px-5 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/20">
              <Icon icon={PlusIcon} className="w-5 h-5" />
              <span>{t('admin.addProduct')}</span>
            </button>
          </div>
          <div className="bg-overlay/5 backdrop-blur-md border border-overlay/10 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-brand-text-secondary">
                      <thead className="text-xs text-brand-text uppercase bg-overlay/5">
                          <tr>
                              <th scope="col" className="px-6 py-3">{t('admin.name')}</th>
                              <th scope="col" className="px-6 py-3">{t('admin.category')}</th>
                              <th scope="col" className="px-6 py-3">{t('admin.price')}</th>
                              <th scope="col" className="px-6 py-3">{t('admin.stock')}</th>
                              <th scope="col" className="px-6 py-3 text-right">{t('admin.actions')}</th>
                          </tr>
                      </thead>
                      <tbody>
                          {products.map((product) => (
                              <tr key={product.id} className="border-b border-overlay/10 hover:bg-overlay/5">
                                  <th scope="row" className="px-6 py-4 font-medium text-brand-text whitespace-nowrap">{product.name}</th>
                                  <td className="px-6 py-4">{product.category}</td>
                                  <td className="px-6 py-4">${product.price.toFixed(2)}</td>
                                  <td className="px-6 py-4">{product.stock}</td>
                                  <td className="px-6 py-4 text-right space-x-4">
                                      <button onClick={() => handleEditProductClick(product)} className="font-medium text-brand-accent hover:underline">{t('admin.edit')}</button>
                                      <button onClick={() => handleDeleteProduct(product.id)} className="font-medium text-red-500 hover:underline">{t('admin.delete')}</button>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
        </section>

        {/* Categories Section */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-brand-text">{t('admin.manageCategories')}</h2>
            <button onClick={handleOpenAddCategory} className="flex items-center space-x-2 bg-brand-accent text-brand-text-on-accent font-semibold py-2 px-5 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/20">
              <Icon icon={PlusIcon} className="w-5 h-5" />
              <span>{t('admin.addNewCategory')}</span>
            </button>
          </div>
          <div className="bg-overlay/5 backdrop-blur-md border border-overlay/10 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left text-brand-text-secondary">
                      <thead className="text-xs text-brand-text uppercase bg-overlay/5">
                          <tr>
                              <th scope="col" className="px-6 py-3">{t('admin.name')}</th>
                              <th scope="col" className="px-6 py-3">{t('admin.group')}</th>
                              <th scope="col" className="px-6 py-3 text-right">{t('admin.actions')}</th>
                          </tr>
                      </thead>
                      <tbody>
                          {categories.map((category) => (
                              <tr key={category.id} className="border-b border-overlay/10 hover:bg-overlay/5">
                                  <th scope="row" className="px-6 py-4 font-medium text-brand-text whitespace-nowrap">{category.name}</th>
                                  <td className="px-6 py-4">{category.group}</td>
                                  <td className="px-6 py-4 text-right space-x-4">
                                      <button onClick={() => handleEditCategoryClick(category)} className="font-medium text-brand-accent hover:underline">{t('admin.edit')}</button>
                                      <button onClick={() => handleDeleteCategory(category.id)} className="font-medium text-red-500 hover:underline">{t('admin.delete')}</button>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
          </div>
        </section>
      </div>

      {isTemplateSelectorOpen && (
        <GameTemplateSelectorModal
          onClose={() => setIsTemplateSelectorOpen(false)}
          onSelectTemplate={handleTemplateSelect}
        />
      )}

      {isProductFormOpen && (
        <ProductFormModal
          productToEdit={productToEdit}
          categories={categories}
          onSave={handleSaveProduct}
          onClose={closeProductForm}
        />
      )}

      {isCategoryFormOpen && (
        <CategoryFormModal
            categoryToEdit={categoryToEdit}
            onSave={handleSaveCategory}
            onClose={closeCategoryForm}
        />
      )}
    </>
  );
};