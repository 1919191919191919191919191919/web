import React, { useMemo } from 'react';
import { CartItem } from '../types';
import { Icon, XMarkIcon, PlusIcon, MinusIcon } from './Icon';
import { useTranslation } from 'react-i18next';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveItem: (productId: string) => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onCheckout: () => void;
}

export const CartSidebar: React.FC<CartSidebarProps> = ({ isOpen, onClose, cartItems, onRemoveItem, onUpdateQuantity, onCheckout }) => {
  const { t } = useTranslation();
  
  const subtotal = useMemo(() => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  }, [cartItems]);

  const transformClass = isOpen ? 'translateX(0)' : 'translateX(100%)';
  const opacityClass = isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none';

  return (
    <div 
      className={`fixed inset-0 bg-black/50 z-50 transition-opacity duration-300 ease-in-out ${opacityClass}`}
      onClick={onClose}
    >
      <div 
        className="fixed top-0 right-0 h-full w-full max-w-sm bg-brand-secondary shadow-2xl flex flex-col transform transition-transform duration-300 ease-in-out"
        style={{ transform: transformClass }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-overlay/10">
          <h2 className="text-xl font-bold text-brand-text">{t('cart.title')}</h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>

        {/* Cart Items */}
        {cartItems.length > 0 ? (
          <div className="flex-grow overflow-y-auto p-6 space-y-6">
            {cartItems.map((item) => (
              <div key={item.id} className="flex items-start space-x-4">
                <img src={item.imageUrl} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
                <div className="flex-grow">
                  <p className="font-bold text-brand-text text-sm leading-tight">{item.name}</p>
                  <p className="text-brand-text-secondary text-xs mt-1">{item.seller.name}</p>
                  <div className="flex items-center mt-2">
                      <div className="flex items-center border border-overlay/10 rounded-md">
                           <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} className="p-1.5 text-brand-text-secondary hover:text-brand-text transition-colors">
                              <Icon icon={MinusIcon} className="w-3 h-3" />
                           </button>
                           <span className="px-2 text-brand-text font-bold text-sm">{item.quantity}</span>
                           <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} className="p-1.5 text-brand-text-secondary hover:text-brand-text transition-colors">
                              <Icon icon={PlusIcon} className="w-3 h-3" />
                           </button>
                      </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-brand-accent font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                  <button 
                      onClick={() => onRemoveItem(item.id)}
                      className="text-brand-text-secondary hover:text-red-500 transition-colors text-xs mt-2 underline"
                  >
                      {t('cart.remove')}
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex-grow flex items-center justify-center">
            <p className="text-brand-text-secondary">{t('cart.empty')}</p>
          </div>
        )}

        {/* Footer */}
        {cartItems.length > 0 && (
          <div className="p-6 border-t border-overlay/10">
            <div className="flex justify-between items-center mb-4">
              <p className="text-brand-text-secondary font-medium">{t('cart.subtotal')}</p>
              <p className="text-brand-text font-bold text-xl">${subtotal.toFixed(2)}</p>
            </div>
            <button
              onClick={onCheckout}
              className="w-full bg-brand-accent text-brand-text-on-accent font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 text-lg"
            >
              {t('cart.checkout')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};