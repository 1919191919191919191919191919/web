import React, { useState, useEffect } from 'react';
import { GameCategory } from '../types';
import { Icon, XMarkIcon } from './Icon';
import { useTranslation } from 'react-i18next';

interface CategoryFormModalProps {
  categoryToEdit: GameCategory | null;
  onSave: (categoryData: Omit<GameCategory, 'id'> | GameCategory) => void;
  onClose: () => void;
}

export const CategoryFormModal: React.FC<CategoryFormModalProps> = ({ categoryToEdit, onSave, onClose }) => {
  const { t } = useTranslation();
  const [name, setName] = useState('');
  const [group, setGroup] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  useEffect(() => {
    if (categoryToEdit) {
      setName(categoryToEdit.name || '');
      setGroup(categoryToEdit.group || '');
      setImageUrl(categoryToEdit.imageUrl || '');
    } else {
      // Reset form for new category
      setName('');
      setGroup('Featured Products');
      setImageUrl('');
    }
  }, [categoryToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const categoryData = {
      name,
      group,
      imageUrl,
    };

    if (categoryToEdit) {
      onSave({ ...categoryToEdit, ...categoryData });
    } else {
      onSave(categoryData);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-lg border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">
            {categoryToEdit ? t('admin.categoryForm.editCategoryTitle') : t('admin.categoryForm.addCategoryTitle')}
          </h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div>
            <label htmlFor="category-name" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.categoryForm.nameLabel')}</label>
            <input type="text" id="category-name" value={name} onChange={e => setName(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
          </div>
          <div>
            <label htmlFor="category-group" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.categoryForm.groupLabel')}</label>
            <input type="text" id="category-group" value={group} onChange={e => setGroup(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
          </div>
          <div>
            <label htmlFor="category-image-url" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.categoryForm.imageUrlLabel')}</label>
            <input type="text" id="category-image-url" value={imageUrl} onChange={e => setImageUrl(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
          </div>
          <div className="pt-6 flex justify-end space-x-4">
             <button type="button" onClick={onClose} className="bg-overlay/10 text-brand-text font-bold py-3 px-6 rounded-lg hover:bg-overlay/20 border border-overlay/10 transition-all duration-300">
               {t('admin.categoryForm.cancel')}
             </button>
             <button type="submit" className="bg-brand-accent text-brand-text-on-accent font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
               {t('admin.categoryForm.save')}
             </button>
          </div>
        </form>
      </div>
    </div>
  );
};