import React, { useState } from 'react';
import { CartItem } from '../types';
import { Icon, ArrowLeftIcon, StripeIcon } from './Icon';
import Spinner from './Spinner';
import { useTranslation } from 'react-i18next';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';

interface CheckoutPageProps {
  cartItems: CartItem[];
  onConfirmPayment: (paidItems: CartItem[], discount: number) => void;
  onBack: () => void;
  onCryptoPayRequest: (items: CartItem[], discount: number) => void;
}

const VALID_COUPONS = {
  'SAVE10': { type: 'percentage', value: 0.10 },
  'FLAT20': { type: 'flat', value: 20 },
};

const StripePaymentForm: React.FC<{
    totalPrice: number, 
    onSuccess: () => void
}> = ({ totalPrice, onSuccess }) => {
    const { t } = useTranslation();
    const stripe = useStripe();
    const elements = useElements();

    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!stripe || !elements) {
            // Stripe.js has not yet loaded.
            return;
        }

        setIsProcessing(true);
        setError(null);

        const { error: paymentError } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                // Make sure to change this to your payment completion page
                return_url: `${window.location.origin}`,
            },
            redirect: 'if_required' // Prevents redirect for this client-only demo
        });

        if (paymentError) {
            setError(paymentError.message || t('checkout.cardError'));
            setIsProcessing(false);
        } else {
            // With redirect: 'if_required', if there's no error, payment succeeded without a redirect.
            console.log('Payment Succeeded');
            onSuccess();
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in-up" style={{animationDuration: '300ms'}}>
            <div>
                <label className="block text-sm font-medium text-brand-text-secondary mb-2">{t('checkout.cardDetails')}</label>
                <div className="bg-overlay/5 border border-overlay/10 rounded-lg p-3.5">
                    <PaymentElement />
                </div>
            </div>

            {error && (
                <div className="text-red-400 text-sm text-center" role="alert">
                    {error}
                </div>
            )}
            
            <div className="pt-4">
                <button 
                  type="submit" 
                  disabled={isProcessing || !stripe || !elements}
                  className="w-full bg-brand-accent text-brand-text-on-accent font-bold py-4 px-4 rounded-lg text-lg hover:bg-brand-accent-hover transition-all duration-300 transform hover:scale-105 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 flex justify-center items-center disabled:bg-gray-600 disabled:shadow-none disabled:cursor-not-allowed">
                  {isProcessing ? <Spinner color="border-white" /> : `${t('checkout.payButton')} $${totalPrice.toFixed(2)}`}
                </button>
            </div>
        </form>
    )
}


export const CheckoutPage: React.FC<CheckoutPageProps> = ({ cartItems, onConfirmPayment, onBack, onCryptoPayRequest }) => {
  const { t } = useTranslation();
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{code: string; discount: number} | null>(null);
  const [couponError, setCouponError] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'crypto'>('card');

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

  const discount = appliedCoupon?.discount || 0;
  const totalPrice = Math.max(0, subtotal - discount);

  const handleApplyCoupon = () => {
    const code = couponCode.toUpperCase();
    const coupon = VALID_COUPONS[code as keyof typeof VALID_COUPONS];
    if (coupon) {
      let discountValue = 0;
      if (coupon.type === 'percentage') {
        discountValue = subtotal * coupon.value;
      } else {
        discountValue = coupon.value;
      }
      setAppliedCoupon({ code, discount: discountValue });
      setCouponError('');
    } else {
      setAppliedCoupon(null);
      setCouponError(t('checkout.invalidCoupon'));
    }
  };

  const handleCryptoPay = () => {
    onCryptoPayRequest(cartItems, discount);
  };
  
  const renderPaymentContent = () => {
    if (paymentMethod === 'card') {
        return (
            <StripePaymentForm 
                totalPrice={totalPrice} 
                onSuccess={() => onConfirmPayment(cartItems, discount)} 
            />
        )
    }
    if (paymentMethod === 'crypto') {
        return (
            <div className="text-center animate-fade-in-up" style={{animationDuration: '300ms'}}>
                <p className="text-brand-text-secondary mb-6">{t('checkout.cryptoInstruction')}</p>
                <button 
                    onClick={handleCryptoPay}
                    className="w-full bg-brand-accent text-brand-text-on-accent font-bold py-4 px-4 rounded-lg text-lg hover:bg-brand-accent-hover transition-all duration-300 transform hover:scale-105 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 flex justify-center items-center">
                    {t('checkout.payWithCrypto')}
                </button>
            </div>
        )
    }
  }

  return (
    <div className="container mx-auto px-6 py-12 animate-fade-in-up opacity-0">
      <button onClick={onBack} className="flex items-center space-x-2 text-brand-text-secondary hover:text-brand-text transition-colors mb-8 group">
        <Icon icon={ArrowLeftIcon} className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
        <span>{t('checkout.back')}</span>
      </button>

      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-extrabold text-brand-text tracking-tight text-center mb-12">{t('checkout.title')}</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Left: Order Summary */}
          <div className="bg-overlay/5 backdrop-blur-md border border-overlay/10 rounded-2xl p-8 flex flex-col">
             <h2 className="text-2xl font-bold text-brand-text mb-6">{t('checkout.summaryTitle')}</h2>
             <div className="space-y-4 flex-grow">
                {cartItems.map(item => (
                    <div key={item.id} className="flex items-center space-x-4">
                        <div className="relative">
                          <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-lg"/>
                          <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-brand-accent text-xs font-bold text-brand-text-on-accent">
                            {item.quantity}
                          </span>
                        </div>
                        <div className="flex-grow">
                            <h3 className="text-md font-bold text-brand-text">{item.name}</h3>
                            <p className="text-sm text-brand-text-secondary">${item.price.toFixed(2)}</p>
                        </div>
                        <p className="font-semibold text-brand-text">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                ))}
             </div>
             
             <div className="space-y-4 mt-6 pt-6 border-t border-overlay/10">
                <div className="flex space-x-2">
                   <input 
                      type="text"
                      value={couponCode}
                      onChange={(e) => { setCouponCode(e.target.value); setCouponError(''); }}
                      placeholder={t('checkout.couponCode')}
                      className="w-full bg-overlay/5 border border-overlay/10 rounded-lg py-2 px-3 text-brand-text placeholder-brand-text-secondary focus:ring-2 focus:ring-brand-accent"
                   />
                   <button onClick={handleApplyCoupon} className="bg-overlay/10 text-brand-text font-semibold py-2 px-5 rounded-lg hover:bg-overlay/20 transition-all">
                      {t('checkout.apply')}
                   </button>
                </div>
                {couponError && <p className="text-sm text-red-400">{couponError}</p>}
                {appliedCoupon && <p className="text-sm text-green-400">{t('checkout.discountApplied', { code: appliedCoupon.code })}</p>}
             </div>
             <div className="mt-6 pt-6 border-t border-overlay/10">
                <div className="flex justify-between items-center text-brand-text-secondary">
                    <span>{t('checkout.subtotal')}</span>
                    <span>${subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                    <div className="flex justify-between items-center text-green-400 mt-2">
                        <span>{t('checkout.discount')} ({appliedCoupon?.code})</span>
                        <span>-${discount.toFixed(2)}</span>
                    </div>
                )}
                 <div className="flex justify-between items-center text-brand-text-secondary mt-2">
                    <span>{t('checkout.fees')}</span>
                    <span>$0.00</span>
                </div>
                <div className="flex justify-between items-center text-brand-text font-bold text-xl mt-4">
                    <span>{t('checkout.total')}</span>
                    <span>${totalPrice.toFixed(2)}</span>
                </div>
             </div>
          </div>

          {/* Right: Payment Form */}
          <div className="bg-overlay/5 backdrop-blur-md border border-overlay/10 rounded-2xl p-8">
            <h2 className="text-2xl font-bold text-brand-text mb-6">{t('checkout.paymentTitle')}</h2>
            
            <div className="flex border-b border-overlay/10 mb-6">
                <button
                    onClick={() => setPaymentMethod('card')}
                    className={`flex items-center justify-center gap-2 px-4 py-3 font-semibold text-sm transition-colors w-1/2 ${paymentMethod === 'card' ? 'text-brand-accent border-b-2 border-brand-accent' : 'text-brand-text-secondary hover:text-brand-text'}`}
                >
                    <Icon icon={StripeIcon} className="w-5 h-5"/>
                    {t('checkout.creditCard')}
                </button>
                <button
                    onClick={() => setPaymentMethod('crypto')}
                    className={`px-4 py-3 font-semibold text-sm transition-colors w-1/2 ${paymentMethod === 'crypto' ? 'text-brand-accent border-b-2 border-brand-accent' : 'text-brand-text-secondary hover:text-brand-text'}`}
                >
                    {t('checkout.cryptocurrency')}
                </button>
            </div>

            {renderPaymentContent()}
          </div>
        </div>
      </div>
    </div>
  );
};