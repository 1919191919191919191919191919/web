import React, { useState, useCallback, useMemo } from 'react';
import { Icon, XMarkIcon, QrCodeIcon, ClipboardIcon } from './Icon';
import Spinner from './Spinner';
import { useTranslation } from 'react-i18next';

interface CryptoPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  totalPrice: number;
  onConfirm: () => void;
}

const ETH_PRICE_USD = 3000; // Mock ETH price
const WALLET_ADDRESS = '0x1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o6p7q8r9s0t';

export const CryptoPaymentModal: React.FC<CryptoPaymentModalProps> = ({ isOpen, onClose, totalPrice, onConfirm }) => {
  const { t } = useTranslation();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  const ethAmount = useMemo(() => (totalPrice / ETH_PRICE_USD).toFixed(6), [totalPrice]);

  const handleCopyAddress = useCallback(() => {
    navigator.clipboard.writeText(WALLET_ADDRESS);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  }, []);

  const handleConfirmPayment = () => {
    setIsProcessing(true);
    // Simulate waiting for blockchain confirmation
    setTimeout(() => {
      onConfirm();
      setIsProcessing(false);
    }, 3000);
  };
  
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-md border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">{t('cryptoModal.title')}</h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10" disabled={isProcessing}>
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-8 text-center">
            {isProcessing ? (
                <div className="py-12 flex flex-col items-center justify-center">
                    <Spinner size="lg" />
                    <p className="mt-4 text-lg font-semibold text-brand-text-secondary">{t('cryptoModal.processing')}</p>
                </div>
            ) : (
                <>
                    <p className="text-brand-text-secondary mb-4">{t('cryptoModal.sendAmount')}</p>
                    <div className="bg-brand-primary p-4 rounded-lg mb-6">
                        <div className="text-3xl font-bold text-brand-text">{ethAmount} <span className="text-brand-accent">ETH</span></div>
                        <div className="text-sm text-brand-text-secondary">~${totalPrice.toFixed(2)} USD</div>
                    </div>
                    
                    <div className="flex justify-center mb-6">
                        <div className="bg-white p-3 rounded-lg">
                           <Icon icon={QrCodeIcon} className="w-32 h-32 text-brand-primary"/>
                        </div>
                    </div>
                    <p className="text-sm text-brand-text-secondary mb-2">{t('cryptoModal.walletAddress')}</p>
                    <div className="relative bg-brand-primary rounded-lg p-3 flex items-center justify-between">
                        <code className="text-sm text-brand-text-secondary truncate pr-10">{WALLET_ADDRESS}</code>
                        <button onClick={handleCopyAddress} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-overlay/10 rounded-md hover:bg-overlay/20 transition-colors">
                            <Icon icon={ClipboardIcon} className="w-5 h-5"/>
                        </button>
                    </div>
                    {isCopied && <p className="text-green-400 text-xs mt-2">{t('cryptoModal.copied')}</p>}

                    <div className="mt-8">
                        <button 
                            onClick={handleConfirmPayment}
                            className="w-full bg-brand-accent text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 text-lg">
                            {t('cryptoModal.confirmButton')}
                        </button>
                    </div>
                </>
            )}
        </div>
      </div>
    </div>
  );
};