import React from 'react';
import { useTranslation } from 'react-i18next';

interface CtaSectionProps {
    onSignUp: () => void;
}

export const CtaSection: React.FC<CtaSectionProps> = ({ onSignUp }) => {
    const { t } = useTranslation();

    return (
        <div className="relative mt-24">
            <div className="container mx-auto px-6">
                <div className="relative bg-brand-secondary border border-white/10 rounded-3xl py-16 sm:py-24 px-6 text-center overflow-hidden">
                    {/* Animated background gradient */}
                    <div className="absolute -inset-px rounded-3xl bg-[radial-gradient(circle_at_50%_120%,_rgba(79,70,229,0.5)_0%,_rgba(79,70,229,0)_50%)] animate-spin-slow-reverse"></div>
                    <div className="absolute -inset-px rounded-3xl bg-[radial-gradient(circle_at_50%_-20%,_rgba(79,70,229,0.5)_0%,_rgba(79,70,229,0)_50%)] animate-spin-slow"></div>

                    <div className="relative z-10">
                        <h2 className="text-4xl md:text-5xl font-black text-brand-text tracking-tighter leading-tight">
                            {t('cta.title')}
                        </h2>
                        <p className="mt-4 max-w-xl mx-auto text-lg text-brand-text-secondary">
                            {t('cta.subtitle')}
                        </p>
                        <div className="mt-8">
                            <button
                                onClick={onSignUp}
                                className="bg-brand-accent text-white font-bold py-4 px-10 rounded-lg text-lg hover:bg-brand-accent-hover transition-all duration-300 transform hover:scale-105 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
                                {t('cta.button')}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};