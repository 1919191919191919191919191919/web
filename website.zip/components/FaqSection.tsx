import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Icon, ChevronDownIcon } from './Icon';

const FaqItem: React.FC<{ question: string; answer: string; }> = ({ question, answer }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="border-b border-overlay/10">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center text-left py-6"
            >
                <span className="text-lg font-semibold text-brand-text">{question}</span>
                <Icon
                    icon={ChevronDownIcon}
                    className={`w-6 h-6 text-brand-accent transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                />
            </button>
            <div
                className={`grid transition-all duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
            >
                <div className="overflow-hidden">
                    <p className="pb-6 text-brand-text-secondary">
                        {answer}
                    </p>
                </div>
            </div>
        </div>
    );
};


export const FaqSection: React.FC = () => {
    const { t } = useTranslation();
    const rawFaqs = t('faq.questions', { returnObjects: true });
    const faqs: { q: string; a: string; }[] = Array.isArray(rawFaqs) ? rawFaqs : [];

    return (
        <div className="relative mt-24 pb-16">
            <div className="container mx-auto px-6">
                <div className="max-w-3xl mx-auto">
                    <h2 className="text-4xl md:text-5xl font-black text-brand-text tracking-tighter leading-tight text-center mb-12">
                        {t('faq.title')}
                    </h2>
                    <div className="space-y-2">
                        {faqs.map((faq, index) => (
                            <FaqItem key={index} question={faq.q} answer={faq.a} />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};