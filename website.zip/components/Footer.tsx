import React from 'react';
import { useTranslation } from 'react-i18next';
import { Icon, SparklesIcon, DiscordIcon } from './Icon';

interface FooterProps {
  onNavigateToAdmin: () => void;
  isAdmin: boolean;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateToAdmin, isAdmin }) => {
  const { t } = useTranslation();
  const year = new Date().getFullYear();
  
  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
      e.preventDefault();
      alert(t('common.notImplemented'));
  };

  return (
    <footer className="bg-brand-secondary/30 mt-24 border-t border-overlay/10">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1: Brand */}
          <div className="flex flex-col space-y-4 col-span-1 sm:col-span-2 lg:col-span-1">
            <div className="flex items-center space-x-2">
              <Icon icon={SparklesIcon} className="w-7 h-7 text-brand-accent" />
              <span className="text-xl font-bold text-brand-text tracking-tight">Vairis</span>
            </div>
            <p className="text-brand-text-secondary text-sm max-w-xs">
              {t('footer.brandDescription')}
            </p>
            <div className="flex space-x-2">
               <a href="https://discord.com" target="_blank" rel="noopener noreferrer" aria-label="Discord" className="text-brand-text-secondary hover:text-brand-text transition-colors bg-overlay/10 p-3 rounded-lg">
                <Icon icon={DiscordIcon} className="w-5 h-5" />
               </a>
            </div>
          </div>

          {/* Column 2: Games */}
          <div>
            <h3 className="font-bold text-brand-text mb-4 uppercase tracking-wider text-sm">{t('footer.games')}</h3>
            <ul className="space-y-3">
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.valorant')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.apexLegends')}</a></li>
            </ul>
          </div>

          {/* Column 3: Social */}
          <div>
            <h3 className="font-bold text-brand-text mb-4 uppercase tracking-wider text-sm">{t('footer.social')}</h3>
            <ul className="space-y-3">
              <li><a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.discord')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.twitter')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.youtube')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.tiktok')}</a></li>
            </ul>
          </div>

          {/* Column 4: Legal */}
          <div>
            <h3 className="font-bold text-brand-text mb-4 uppercase tracking-wider text-sm">{t('footer.legal')}</h3>
            <ul className="space-y-3">
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.faq')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.purchaseGuide')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.contactUs')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.terms')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.privacy')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.refundPolicy')}</a></li>
              <li><a href="#" onClick={handleLinkClick} className="text-brand-text-secondary hover:text-brand-text transition-colors text-sm">{t('footer.legalNotice')}</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-overlay/10 flex flex-col sm:flex-row justify-between items-center text-center sm:text-left">
          <div className="text-brand-text-secondary text-xs mb-4 sm:mb-0">
            {t('footer.copyright', { year })}
          </div>
          <div className="flex items-center space-x-6">
            {isAdmin && (
              <button onClick={onNavigateToAdmin} className="text-xs text-brand-text-secondary hover:text-brand-text transition-colors">
                {t('admin.title')}
              </button>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};