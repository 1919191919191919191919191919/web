import React from 'react';
import { GameTemplate } from '../types';
import { Icon, XMarkIcon } from './Icon';
import { useTranslation } from 'react-i18next';
import { GAME_TEMPLATES } from '../constants';

interface GameTemplateSelectorModalProps {
  onClose: () => void;
  onSelectTemplate: (template: GameTemplate | null) => void;
}

export const GameTemplateSelectorModal: React.FC<GameTemplateSelectorModalProps> = ({ onClose, onSelectTemplate }) => {
  const { t } = useTranslation();

  return (
    <div
      className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-3xl border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">{t('admin.templateSelector.title')}</h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        <div className="p-8 max-h-[70vh] overflow-y-auto">
          <p className="text-brand-text-secondary mb-6 text-center">{t('admin.templateSelector.subtitle')}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {GAME_TEMPLATES.map((template) => (
              <button
                key={template.name}
                onClick={() => onSelectTemplate(template)}
                className="bg-overlay/5 rounded-lg p-4 text-center group transition-all duration-300 hover:bg-overlay/10 hover:border-brand-accent/50 border border-transparent"
              >
                <img src={template.imageUrl} alt={template.name} className="w-full h-24 object-cover rounded-md mb-3" />
                <span className="font-semibold text-brand-text group-hover:text-brand-accent">{template.name}</span>
              </button>
            ))}
          </div>
          <div className="mt-8 text-center">
            <button 
              onClick={() => onSelectTemplate(null)} 
              className="text-brand-accent hover:text-brand-accent-hover underline font-semibold"
            >
              {t('admin.templateSelector.custom')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};