import React from 'react';
import { Icon, SparklesIcon, UserCircleIcon, ShoppingCartIcon, SearchIcon } from './Icon';
import { User } from '../types';
import { useTranslation } from 'react-i18next';
import { LanguageSelector } from './LanguageSelector';
import { ThemeSwitcher } from './ThemeSwitcher';

interface HeaderProps {
  isLoggedIn: boolean;
  currentUser: User | null;
  onSignIn: () => void;
  onSignUp: () => void;
  onSignOut: () => void;
  cartItemCount: number;
  onCartClick: () => void;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  theme: string;
  setTheme: (theme: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ isLoggedIn, onSignIn, onSignUp, onSignOut, cartItemCount, onCartClick, searchTerm, onSearchChange, theme, setTheme }) => {
  const { t } = useTranslation();
  
  return (
    <header className="bg-brand-primary/70 backdrop-blur-lg sticky top-0 z-50 border-b border-overlay/10">
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
           <Icon icon={SparklesIcon} className="w-7 h-7 text-brand-accent" />
           <span className="text-xl font-bold text-brand-text tracking-tight">Vairis</span>
        </div>
        
        <div className="hidden md:flex flex-1 justify-center px-8">
          <div className="relative w-full max-w-lg">
            <Icon icon={SearchIcon} className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-brand-text-secondary pointer-events-none" />
            <input
              type="search"
              placeholder={t('header.searchPlaceholder', 'Search for products, games, etc...')}
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-overlay/5 border border-overlay/10 rounded-lg py-2.5 pl-12 pr-4 text-brand-text placeholder-brand-text-secondary focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition"
              aria-label={t('header.searchPlaceholder', 'Search for products, games, etc...')}
            />
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-4">
          <ThemeSwitcher theme={theme} setTheme={setTheme} />
          <LanguageSelector />
          
          <button onClick={onCartClick} className="relative text-brand-text-secondary hover:text-brand-text transition-colors p-2">
            <Icon icon={ShoppingCartIcon} className="w-6 h-6" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-brand-accent text-xs font-bold text-brand-text-on-accent">
                {cartItemCount}
              </span>
            )}
          </button>

          {isLoggedIn ? (
            <div className="flex items-center space-x-4">
              <Icon icon={UserCircleIcon} className="w-7 h-7 text-brand-text-secondary" />
              <button 
                onClick={onSignOut}
                className="bg-overlay/10 text-brand-text font-semibold py-2 px-5 rounded-lg hover:bg-overlay/20 border border-overlay/10 transition-all duration-300 text-sm">
                {t('header.signOut')}
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
               <button 
                onClick={onSignUp}
                className="bg-transparent text-brand-text-secondary font-medium py-2 px-4 rounded-lg hover:text-brand-text transition-colors text-sm">
                {t('header.signUp')}
              </button>
              <button 
                onClick={onSignIn}
                className="bg-brand-accent text-brand-text-on-accent font-semibold py-2 px-5 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 text-sm shadow-lg shadow-brand-accent/20 hover:shadow-glow hover:shadow-brand-accent/40">
                {t('header.signIn')}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};