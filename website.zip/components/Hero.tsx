import React from 'react';
import { useTranslation, Trans } from 'react-i18next';

interface HeroProps {
    onSignUp: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSignUp }) => {
  const { t } = useTranslation();

  const handleExploreClick = () => {
    const productsSection = document.getElementById('products-section');
    if (productsSection) {
        productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center text-center relative overflow-hidden py-16">
        <div className="container mx-auto px-6 relative z-10">
            <h1 className="text-5xl sm:text-7xl md:text-8xl font-black text-brand-text tracking-tighter leading-tight animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                <Trans i18nKey="hero.title">
                    The Premier Marketplace<br />for <span className="text-brand-accent">Digital Goods</span>
                </Trans>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-brand-text-secondary animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
                {t('hero.subtitle')}
            </p>
            <div className="mt-10 flex justify-center items-center space-x-4 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
                <button 
                  onClick={handleExploreClick}
                  className="bg-brand-accent text-brand-text-on-accent font-bold py-3 px-8 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 transform hover:scale-105 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
                    {t('hero.exploreButton')}
                </button>
                <button 
                  onClick={onSignUp}
                  className="bg-overlay/10 text-brand-text font-bold py-3 px-8 rounded-lg hover:bg-overlay/20 border border-overlay/10 transition-all duration-300">
                    {t('hero.sellerButton')}
                </button>
            </div>
        </div>
    </div>
  );
};