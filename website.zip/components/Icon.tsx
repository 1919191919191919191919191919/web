

import React from 'react';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export const Icon: React.FC<IconProps> = ({ icon: IconComponent, ...props }) => {
  return <IconComponent {...props} />;
};

export const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    {...props}
  >
    <path
      fillRule="evenodd"
      d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.007z"
      clipRule="evenodd"
    />
  </svg>
);

export const VerifiedIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    {...props}>
    <path 
      fillRule="evenodd" 
      d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12c0 1.357-.6 2.573-1.549 3.397a4.49 4.49 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.491 4.491 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
      clipRule="evenodd" />
  </svg>
);

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    {...props}>
    <path 
      fillRule="evenodd" 
      d="M9.315 7.584C10.866 6.33 13.134 6.33 14.685 7.584l.043.033.043.033.043.033.043.033c1.552 1.25 1.552 3.27 0 4.52l-.043.033-.043.033-.043.033-.043.033c-1.552 1.25-3.819 1.25-5.37 0l-.043-.033-.043-.033-.043-.033-.043-.033a3.185 3.185 0 010-4.52zM12 1.5c-5.798 0-10.5 4.702-10.5 10.5s4.702 10.5 10.5 10.5S22.5 17.798 22.5 12 17.798 1.5 12 1.5zM2.25 12a9.75 9.75 0 019.75-9.75 9.75 9.75 0 019.75 9.75 9.75 9.75 0 01-9.75 9.75A9.75 9.75 0 012.25 12z" 
      clipRule="evenodd" />
  </svg>
);

export const ArrowLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    {...props}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"
    />
  </svg>
);

export const SearchIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
  </svg>
);

export const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

export const UserCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      fill="none" 
      viewBox="0 0 24 24" 
      strokeWidth={1.5} 
      stroke="currentColor" 
      {...props}>
      <path 
        strokeLinecap="round" 
        strokeLinejoin="round" 
        d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

export const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 20 20" 
      fill="currentColor" 
      {...props}>
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
    </svg>
);

export const CreditCardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth="1.5" 
    stroke="currentColor" 
    {...props}>
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15A2.25 2.25 0 002.25 6.75v10.5A2.25 2.25 0 004.5 19.5z" />
  </svg>
);

export const ShoppingCartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    strokeWidth={1.5}
    stroke="currentColor"
    {...props}>
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c.51 0 .962-.344 1.087-.849l1.858-6.443a.75.75 0 00-.7-1.002H5.632l-.671-2.5-1.14-4.242a.75.75 0 00-.7-.525H2.25m3.75 10.5h11.25"
    />
  </svg>
);

export const GlobeAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c1.355 0 2.707-.157 4.018-.45M12 21c-1.355 0-2.707-.157-4.018-.45M3.284 15.751c-.023.18-.044.358-.063.539M20.716 15.751c.023.18.044.358.063.539m-17.5 0a9.004 9.004 0 0117.5 0M4.125 10.5h15.75M4.125 10.5a9.004 9.004 0 0115.75 0M4.125 10.5a9.004 9.004 0 0015.75 0M12 3c-1.355 0-2.707.157-4.018.45M12 3c1.355 0 2.707.157 4.018.45M12 3v18m9-9h-18" />
  </svg>
);

export const PlusIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);

export const MinusIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 12H6" />
  </svg>
);

export const DiscordIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    role="img"
    viewBox="0 0 251 193"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
    {...props}>
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M210.2,25c-17.9-10.1-37.5-17.2-58.2-21C150.9,2,149.7,0,147.4,0c-2,0-3.9,0.6-5.5,1.8C140,3.3,138.8,5.3,137.9,7.1C119.5,10,102.1,15.4,85.5,23.5C41.2,52.9,21.7,88,21.7,125c0,36.4,21.9,69.6,55.5,89.1c11.9,7.8,24.8,14,38.4,18.4c1.4,2.4,2.9,4.7,4.6,6.8c2.9,3.5,6.9,5.2,11.1,5.2s8.2-1.7,11.1-5.2c1.7-2.1,3.2-4.4,4.6-6.8c13.6-4.4,26.5-10.6,38.4-18.4c33.6-19.5,55.5-52.7,55.5-89.1C240.9,88,221.3,52.8,176.8,25L210.2,25z M69.7,118.3a23,23 0 1 0 46,0a23,23 0 1 0 -46,0z M147.1,118.3a23,23 0 1 0 46,0a23,23 0 1 0 -46,0z"
    />
  </svg>
);

export const ChevronDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        xmlns="http://www.w3.org/2000/svg" 
        fill="none" 
        viewBox="0 0 24 24" 
        strokeWidth={2} 
        stroke="currentColor" 
        {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
    </svg>
);

export const QrCodeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H3.75V4.5zM3.75 9a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H3.75V9zM9 3.75a.75.75 0 00-.75.75v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H9V4.5zM9.75 9a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H9.75V9zM9 14.25a.75.75 0 00-.75.75v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H9v-1.5zM15 3.75a.75.75 0 00-.75.75v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H15V4.5zM15.75 9a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H15.75V9zM15 14.25a.75.75 0 00-.75.75v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H15v-1.5zM4.5 19.5a.75.75 0 00-1.5 0v1.5A.75.75 0 003.75 21h1.5a.75.75 0 000-1.5H4.5v-1.5zM19.5 4.5a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H19.5V4.5zM19.5 9a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H19.5V9zM19.5 14.25a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H19.5v-1.5zM9.75 19.5a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H9.75v-1.5zM15.75 19.5a.75.75 0 00-1.5 0v1.5c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5H15.75v-1.5z" />
  </svg>
);

export const ClipboardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    fill="none" 
    viewBox="0 0 24 24" 
    strokeWidth={1.5} 
    stroke="currentColor" 
    {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75c0-.231-.035-.454-.1-.664M6.75 7.5h1.5v-1.5h-1.5v1.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9h15v11.25c0 1.242-1.008 2.25-2.25 2.25h-10.5A2.25 2.25 0 013.75 20.25V9z" />
  </svg>
);

export const StripeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        width="38" 
        height="26" 
        viewBox="0 0 38 26" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        {...props}>
        <g clipPath="url(#clip0_104_2)">
        <path d="M34.8093 9.77095C34.6293 9.49095 34.3693 9.29095 34.0293 9.20095C33.1993 8.97095 32.2293 9.17095 31.6493 9.77095L25.3393 16.091L27.4693 18.221C28.2393 18.991 29.4793 18.991 30.2493 18.221L34.8093 13.661C35.3993 13.081 35.3993 12.111 34.8093 11.531L32.2593 8.97095C33.0293 8.20095 34.2593 8.20095 35.0393 8.97095C35.8093 9.75095 35.8093 10.991 35.0393 11.761L32.4893 14.311L34.8093 11.991C35.3893 11.411 35.3893 10.441 34.8093 9.77095Z" fill="#635BFF"/>
        <path d="M12.9806 0.969141L0.690625 13.2591C-0.229375 14.1791 -0.229375 15.6591 0.690625 16.5791L6.74063 22.6291C7.66063 23.5491 9.14062 23.5491 10.0606 22.6291L22.3506 10.3391L12.9806 0.969141Z" fill="#635BFF"/>
        <path d="M37.3104 0.689094C36.3904 -0.230906 34.9104 -0.230906 34.0004 0.689094L24.8104 9.87909L28.1904 13.2591L37.3104 4.13909C38.2304 3.21909 38.2304 1.73909 37.3104 0.689094Z" fill="#635BFF"/>
        <path d="M15.4293 18.221L13.2993 16.091L3.1893 26.001C4.0193 26.231 4.9893 26.031 5.5693 25.431L15.4293 15.571L17.5593 13.441L19.6893 11.311L16.3093 7.931L15.4293 8.811L12.6993 11.541C11.9293 12.311 11.9293 13.551 12.6993 14.321L15.4293 17.061V17.061C16.0093 17.641 16.9793 17.821 17.7793 17.521L15.4293 19.871V18.221Z" fill="#635BFF"/>
        </g>
        <defs>
        <clipPath id="clip0_104_2">
        <rect width="38" height="26" fill="white"/>
        </clipPath>
        </defs>
    </svg>
);

export const PaintBrushIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.098 19.902a3.75 3.75 0 0 0 5.304 0l6.401-6.402a3.75 3.75 0 0 0-.625-6.25a3.75 3.75 0 0 0-6.25-.625L3.125 13.5a3.75 3.75 0 0 0 0 5.304Z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.75v1.5M12.75 19.5v1.5M4.875 12h-1.5M20.625 12h-1.5M17.18 6.82l-1.06-1.06M7.88 17.18l-1.06-1.06M17.18 17.18l-1.06 1.06M7.88 6.82l-1.06 1.06" />
    </svg>
);