import React from 'react';
import { CartItem } from '../types';
import { Icon, CheckCircleIcon } from './Icon';
import { useTranslation } from 'react-i18next';

interface OrderConfirmationPageProps {
  purchasedItems: CartItem[];
  discount: number;
  onReturnHome: () => void;
}

export const OrderConfirmationPage: React.FC<OrderConfirmationPageProps> = ({ purchasedItems, discount, onReturnHome }) => {
  const { t } = useTranslation();
  
  const subtotal = purchasedItems.reduce((total, item) => total + item.price * item.quantity, 0);
  const totalPrice = Math.max(0, subtotal - discount);

  return (
    <div className="container mx-auto px-6 py-24 flex flex-col items-center justify-center text-center animate-fade-in-up opacity-0">
        <div className="bg-overlay/5 backdrop-blur-md border border-overlay/10 rounded-2xl p-12 max-w-2xl w-full">
            <Icon icon={CheckCircleIcon} className="w-20 h-20 text-green-400 mx-auto mb-6" />
            <h1 className="text-4xl font-extrabold text-brand-text tracking-tight">{t('confirmation.title')}</h1>
            <p className="text-brand-text-secondary mt-4 max-w-md mx-auto">
                {t('confirmation.subtitle')}
            </p>

            <div className="mt-10 mb-8 text-left bg-brand-secondary/50 p-6 rounded-lg space-y-4">
                 <h2 className="text-lg font-bold text-brand-text mb-4">{t('confirmation.summaryTitle')}</h2>
                 {purchasedItems.map(item => (
                    <div key={item.id} className="flex items-center space-x-4">
                        <div className="relative">
                          <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-cover rounded-lg"/>
                          <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-brand-accent text-xs font-bold text-brand-text-on-accent">
                            {item.quantity}
                          </span>
                        </div>
                        <div>
                            <h3 className="font-bold text-brand-text">{item.name}</h3>
                            <p className="text-sm text-brand-text-secondary">${item.price.toFixed(2)} each</p>
                        </div>
                        <div className="ml-auto font-bold text-brand-text">
                            ${(item.price * item.quantity).toFixed(2)}
                        </div>
                    </div>
                 ))}
                 <div className="border-t border-overlay/10 mt-4 pt-4 space-y-2">
                    <div className="flex justify-between items-center text-brand-text-secondary">
                      <span>{t('checkout.subtotal')}</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between items-center text-green-400">
                        <span>{t('checkout.discount')}</span>
                        <span>-${discount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center font-bold text-brand-text text-lg">
                      <span>{t('confirmation.total')}</span>
                      <span>${totalPrice.toFixed(2)}</span>
                    </div>
                 </div>
            </div>

            <button 
                onClick={onReturnHome}
                className="bg-brand-accent text-brand-text-on-accent font-bold py-3 px-8 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 transform hover:scale-105 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
                {t('confirmation.returnButton')}
            </button>
        </div>
    </div>
  );
};