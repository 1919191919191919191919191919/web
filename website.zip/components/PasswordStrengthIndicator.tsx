import React, { useMemo } from 'react';
import { Icon, CheckCircleIcon } from './Icon';
import { useTranslation } from 'react-i18next';

interface PasswordRequirementProps {
  text: string;
  met: boolean;
}

const PasswordRequirement: React.FC<PasswordRequirementProps> = ({ text, met }) => (
  <li className={`flex items-center text-sm transition-colors duration-300 ${met ? 'text-green-400' : 'text-brand-text-secondary'}`}>
    <Icon icon={CheckCircleIcon} className={`w-4 h-4 mr-2 flex-shrink-0 ${met ? 'text-green-400' : 'text-gray-600'}`} />
    {text}
  </li>
);

export const PasswordStrengthIndicator: React.FC<{ password?: string }> = ({ password = '' }) => {
  const { t } = useTranslation();

  const requirements = useMemo(() => {
    return [
      { text: t('password.length'), met: password.length >= 8 },
      { text: t('password.uppercase'), met: /[A-Z]/.test(password) },
      { text: t('password.lowercase'), met: /[a-z]/.test(password) },
      { text: t('password.number'), met: /[0-9]/.test(password) },
      { text: t('password.special'), met: /[!@#$%^&*(),.?":{}|<>]/.test(password) },
    ];
  }, [password, t]);

  return (
    <ul className="space-y-2 mt-4">
      {requirements.map((req) => (
        <PasswordRequirement key={req.text} text={req.text} met={req.met} />
      ))}
    </ul>
  );
};