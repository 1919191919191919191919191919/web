import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelectProduct }) => {
  return (
    <article
      onClick={() => onSelectProduct(product)}
      aria-labelledby={`product-name-${product.id}`}
      className="relative aspect-[2/3] w-full bg-brand-secondary rounded-2xl group transition-all duration-300 ease-in-out border border-overlay/10 hover:border-brand-accent/50 hover:shadow-glow hover:shadow-brand-accent/10 cursor-pointer overflow-hidden"
    >
      <img
        src={product.imageUrl}
        alt={product.name}
        className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
      />

      <div className="absolute inset-0 bg-diagonal-stripes opacity-20 group-hover:opacity-30 transition-opacity duration-300"></div>

      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>

      <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 flex items-end">
        <h3
          id={`product-name-${product.id}`}
          className="text-brand-text font-black uppercase tracking-wider text-xl sm:text-2xl"
          style={{ textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}
        >
          {product.name}
        </h3>
      </div>
    </article>
  );
};