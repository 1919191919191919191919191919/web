
import React, {useState} from 'react';
import { Product } from '../types';
import { Icon, VerifiedIcon, ArrowLeftIcon, PlusIcon, MinusIcon } from './Icon';
import { StarRating } from './StarRating';
import { useTranslation } from 'react-i18next';

interface ProductDetailPageProps {
  product: Product;
  onBack: () => void;
  isLoggedIn: boolean;
  onRequestAuth: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onBuyNow: (product: Product, quantity: number) => void;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ product, onBack, isLoggedIn, onRequestAuth, onAddToCart, onBuyNow }) => {
  const { t } = useTranslation();
  const [quantity, setQuantity] = useState(1);

  const handleBuyNowClick = () => {
    // Buy Now always requires auth
    if (isLoggedIn) {
      onBuyNow(product, quantity);
    } else {
      onRequestAuth();
    }
  };
  
  const handleQuantityChange = (amount: number) => {
    const newQuantity = quantity + amount;
    if (newQuantity >= 1) {
       if (product.stock === 'Unlimited' || newQuantity <= product.stock) {
           setQuantity(newQuantity);
       }
    }
  }

  return (
    <div className="container mx-auto px-6 py-12 animate-fade-in-up opacity-0">
      <button onClick={onBack} className="flex items-center space-x-2 text-brand-text-secondary hover:text-brand-text transition-colors mb-8 group">
        <Icon icon={ArrowLeftIcon} className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
        <span>{t('productDetail.back')}</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
        {/* Left Column: Image and Details */}
        <div className="lg:col-span-3">
          <div className="w-full h-auto rounded-xl shadow-2xl overflow-hidden border border-white/10 mb-8">
            <img src={product.imageUrl} alt={product.name} className="w-full object-cover aspect-video" />
          </div>

          <div className="prose prose-invert max-w-none prose-p:text-brand-text-secondary prose-headings:text-brand-text">
             <h2 className="text-2xl font-bold border-b border-white/10 pb-4 mb-4">{t('productDetail.description')}</h2>
             <p>{product.description}</p>
          </div>
        </div>

        {/* Right Column: Purchase Box */}
        <div className="lg:col-span-2">
          <div className="sticky top-24 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 flex flex-col">
            <span className="text-sm font-semibold text-brand-accent uppercase tracking-wider">{product.category}</span>
            <h1 className="text-3xl font-black text-brand-text mt-2 mb-4 tracking-tight">{product.name}</h1>
            
            <div className="flex items-center space-x-4 mb-6 border-b border-t border-white/10 py-4">
              <img src={product.seller.avatarUrl} alt={product.seller.name} className="w-10 h-10 rounded-full border-2 border-brand-secondary" />
              <div className="flex items-center">
                <span className="text-md text-brand-text font-medium">{product.seller.name}</span>
                {product.seller.isVerified && (
                   <Icon icon={VerifiedIcon} className="w-5 h-5 text-brand-accent ml-2" />
                )}
              </div>
            </div>
            
            <div className="flex items-center mb-6">
              <StarRating rating={product.rating} />
              <span className="text-sm text-brand-text-secondary ml-3">({product.reviews} {t('productDetail.reviews')})</span>
            </div>
            
            <div className="mt-auto space-y-4">
               <div className="flex justify-between items-center">
                  <div>
                    <p className="text-5xl font-extrabold text-brand-text">${product.price.toFixed(2)}</p>
                  </div>
                  <div>
                     <p className="text-sm text-brand-text-secondary text-right">{t('productDetail.stock')}</p>
                     <p className={`text-lg font-bold text-right ${product.stock === 'Unlimited' ? 'text-green-400' : 'text-brand-text'}`}>
                      {product.stock}
                     </p>
                  </div>
               </div>

              <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                      <label htmlFor="quantity" className="text-sm text-brand-text-secondary mr-3">{t('productDetail.quantity')}:</label>
                      <div className="flex items-center border border-white/10 rounded-lg">
                           <button onClick={() => handleQuantityChange(-1)} className="p-2 text-brand-text-secondary hover:text-brand-text transition-colors disabled:opacity-50" disabled={quantity <= 1}>
                              <Icon icon={MinusIcon} className="w-4 h-4" />
                           </button>
                           <span className="px-4 text-brand-text font-bold">{quantity}</span>
                           <button onClick={() => handleQuantityChange(1)} className="p-2 text-brand-text-secondary hover:text-brand-text transition-colors disabled:opacity-50" disabled={product.stock !== 'Unlimited' && quantity >= product.stock}>
                              <Icon icon={PlusIcon} className="w-4 h-4" />
                           </button>
                      </div>
                  </div>
              </div>
               
              <div className="flex items-center space-x-4">
                  <button 
                      onClick={() => onAddToCart(product, quantity)}
                      className="flex-1 bg-white/10 text-brand-text font-bold py-4 px-4 rounded-lg text-lg hover:bg-white/20 border border-white/10 transition-all duration-300">
                    {t('productDetail.addToCart')}
                  </button>
                  <button 
                    onClick={handleBuyNowClick}
                    className="flex-1 bg-brand-accent text-white font-bold py-4 px-4 rounded-lg text-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
                    {t('productDetail.buyNow')}
                  </button>
              </div>
              <p className="text-center text-xs text-brand-text-secondary pt-2">{t('productDetail.securePayment')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
