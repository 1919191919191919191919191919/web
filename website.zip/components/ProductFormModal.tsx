import React, { useState, useEffect } from 'react';
import { Product, GameCategory } from '../types';
import { Icon, XMarkIcon } from './Icon';
import { useTranslation } from 'react-i18next';

interface ProductFormModalProps {
  productToEdit: Partial<Product> | null;
  categories: GameCategory[];
  onSave: (productData: Omit<Product, 'id' | 'seller' | 'rating' | 'reviews'> | Product) => void;
  onClose: () => void;
}

export const ProductFormModal: React.FC<ProductFormModalProps> = ({ productToEdit, categories, onSave, onClose }) => {
  const { t } = useTranslation();
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [stock, setStock] = useState('');
  const [isUnlimitedStock, setIsUnlimitedStock] = useState(false);

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name || '');
      setCategory(productToEdit.category || '');
      setPrice(productToEdit.price != null ? String(productToEdit.price) : '');
      setDescription(productToEdit.description || '');
      setImageUrl(productToEdit.imageUrl || '');
      if (productToEdit.stock === 'Unlimited') {
        setIsUnlimitedStock(true);
        setStock('');
      } else {
        setIsUnlimitedStock(false);
        setStock(productToEdit.stock != null ? String(productToEdit.stock) : '');
      }
    } else {
      // Reset form for new product
      setName('');
      setCategory(categories.length > 0 ? categories[0].name : '');
      setPrice('');
      setDescription('');
      setImageUrl('');
      setStock('');
      setIsUnlimitedStock(false);
    }
  }, [productToEdit, categories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const stockValue: Product['stock'] = isUnlimitedStock ? 'Unlimited' : Number(stock);
    const productData = {
      name,
      category,
      price: Number(price),
      description,
      imageUrl,
      stock: stockValue,
    };

    if (productToEdit && 'id' in productToEdit) {
      onSave({ ...productToEdit, ...productData, id: productToEdit.id as string });
    } else {
      onSave(productData);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-2xl border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">
            {productToEdit && 'id' in productToEdit ? t('admin.productForm.editProductTitle') : t('admin.productForm.addProductTitle')}
          </h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 max-h-[70vh] overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="product-name" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.nameLabel')}</label>
              <input type="text" id="product-name" value={name} onChange={e => setName(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
            </div>
            <div>
              <label htmlFor="product-category" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.categoryLabel')}</label>
              <select 
                id="product-category" 
                value={category} 
                onChange={e => setCategory(e.target.value)} 
                className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition appearance-none" 
                required
              >
                {categories.map(cat => (
                  <option key={cat.id} value={cat.name} className="bg-brand-secondary text-brand-text">{cat.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="product-price" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.priceLabel')}</label>
              <input type="number" step="0.01" id="product-price" value={price} onChange={e => setPrice(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
            </div>
            <div>
              <label htmlFor="product-stock" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.stockLabel')}</label>
              <input type="number" id="product-stock" value={stock} onChange={e => setStock(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" disabled={isUnlimitedStock} required={!isUnlimitedStock} />
              <div className="flex items-center mt-2">
                  <input type="checkbox" id="unlimited-stock" checked={isUnlimitedStock} onChange={e => setIsUnlimitedStock(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-brand-accent focus:ring-brand-accent bg-overlay/10" />
                  <label htmlFor="unlimited-stock" className="ml-2 block text-sm text-brand-text-secondary">{t('admin.productForm.stockUnlimited')}</label>
              </div>
            </div>
            <div className="md:col-span-2">
              <label htmlFor="product-image-url" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.imageUrlLabel')}</label>
              <input type="text" id="product-image-url" value={imageUrl} onChange={e => setImageUrl(e.target.value)} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="product-description" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('admin.productForm.descriptionLabel')}</label>
              <textarea id="product-description" value={description} onChange={e => setDescription(e.target.value)} rows={4} className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" required />
            </div>
          </div>
          <div className="pt-8 flex justify-end space-x-4">
             <button type="button" onClick={onClose} className="bg-overlay/10 text-brand-text font-bold py-3 px-6 rounded-lg hover:bg-overlay/20 border border-overlay/10 transition-all duration-300">
               {t('admin.productForm.cancel')}
             </button>
             <button type="submit" className="bg-brand-accent text-brand-text-on-accent font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50">
               {t('admin.productForm.save')}
             </button>
          </div>
        </form>
      </div>
    </div>
  );
};