

import React, { useMemo } from 'react';
import { Product, GameCategory } from '../types';
import { ProductCard } from './ProductCard';
import { useTranslation } from 'react-i18next';
import { Icon, ArrowLeftIcon } from './Icon';

interface ProductListProps {
  products: Product[];
  categories: GameCategory[];
  selectedCategory: string | null;
  onSelectCategory: (name: string) => void;
  onSelectProduct: (product: Product) => void;
  onBack: () => void;
}

export const ProductList: React.FC<ProductListProps> = ({ products, categories, selectedCategory, onSelectCategory, onSelectProduct, onBack }) => {
  const { t } = useTranslation();

  const categoriesByGroup = useMemo(() => {
    return categories.reduce((acc, category) => {
      const group = category.group || t('products.uncategorized');
      if (!acc[group]) {
        acc[group] = [];
      }
      acc[group].push(category);
      return acc;
    }, {} as Record<string, GameCategory[]>);
  }, [categories, t]);

  const categoryGroups = Object.keys(categoriesByGroup);

  if (selectedCategory) {
    // VIEW: Displaying products for a selected category
    return (
      <div>
        <div className="flex items-center mb-8">
            <button onClick={onBack} className="flex items-center space-x-2 text-brand-text-secondary hover:text-brand-text transition-colors group">
              <Icon icon={ArrowLeftIcon} className="w-5 h-5 transition-transform group-hover:-translate-x-1" />
              <span>{t('productDetail.back')}</span>
            </button>
        </div>
        <h2 className="text-4xl font-extrabold text-brand-text tracking-tight mb-8">{selectedCategory}</h2>
        
        {products.length > 0 ? (
           <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {products.map((product, index) => (
              <div
                key={product.id}
                className={`opacity-0 animate-fade-in-up`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <ProductCard product={product} onSelectProduct={onSelectProduct} />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <h3 className="text-xl text-brand-text-secondary">{t('products.noResults')}</h3>
          </div>
        )}
      </div>
    );
  }

  // VIEW: Displaying categories
  if (categories.length === 0) {
    return (
      <div className="text-center py-16">
        <h3 className="text-xl text-brand-text-secondary">{t('products.noResults')}</h3>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {categoryGroups.map((group) => (
        <section key={group} aria-labelledby={`category-title-${group.replace(/\s+/g, '-')}`}>
          <h2 id={`category-title-${group.replace(/\s+/g, '-')}`} className="text-2xl font-bold text-brand-text tracking-tight mb-6">{group}</h2>
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {categoriesByGroup[group].map((category, index) => {
              // Adapt GameCategory to Product-like structure for ProductCard
              const categoryAsProduct: Product = {
                id: category.name,
                name: category.name,
                imageUrl: category.imageUrl,
                category: category.group,
                price: 0,
                description: '',
                seller: { name: '', avatarUrl: '', isVerified: false },
                rating: 0,
                reviews: 0,
                stock: 'Unlimited'
              };
              return (
                <div
                  key={category.name}
                  className={`opacity-0 animate-fade-in-up`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <ProductCard product={categoryAsProduct} onSelectProduct={() => onSelectCategory(category.name)} />
                </div>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
};
