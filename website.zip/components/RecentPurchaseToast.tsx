import React from 'react';
import { useTranslation } from 'react-i18next';
import { NotificationData } from '../types';

interface RecentPurchaseToastProps {
  notification: NotificationData;
}

export const RecentPurchaseToast: React.FC<RecentPurchaseToastProps> = ({ notification }) => {
  const { t, i18n } = useTranslation();
  
  const timeString = notification.timestamp.toLocaleTimeString(i18n.language.split('-')[0] || 'en', {
    hour: 'numeric',
    minute: 'numeric',
    hour12: false,
  });

  return (
    <div className="fixed bottom-4 left-4 z-50 w-full max-w-sm animate-fade-in-up" role="status" aria-live="polite">
      <div className="bg-brand-secondary/90 backdrop-blur-sm border border-white/10 rounded-xl shadow-2xl overflow-hidden flex items-stretch">
        <div className="flex-grow p-4 pr-2 flex flex-col justify-center">
          <p className="text-sm text-brand-text-secondary">{t('toast.purchased')}</p>
          <p className="font-bold text-lg text-brand-text my-0.5 leading-tight">{notification.productName}</p>
          <div className="text-xs text-brand-text-secondary mt-1 space-y-0.5">
            <p>Today at {timeString}</p>
            <p className="truncate">{t('toast.from')} {notification.location}</p>
          </div>
        </div>
        <div className="flex-shrink-0">
          <img src={notification.imageUrl} alt={notification.productName} className="w-24 h-full object-cover" />
        </div>
      </div>
    </div>
  );
};
