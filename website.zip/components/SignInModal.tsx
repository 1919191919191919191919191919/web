import React, { useState } from 'react';
import { User } from '../types';
import { Icon, XMarkIcon } from './Icon';
import { useTranslation, Trans } from 'react-i18next';

interface SignInModalProps {
  onClose: () => void;
  onSignIn: (user: User) => void;
  onSwitchToSignUp: () => void;
}

export const SignInModal: React.FC<SignInModalProps> = ({ onClose, onSignIn, onSwitchToSignUp }) => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      alert('Please enter both email and password.');
      return;
    }
    onSignIn({ email });
  };

  return (
    <div 
        className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-md border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">{t('signInModal.title')}</h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('signInModal.emailLabel')}</label>
            <input 
              type="email" 
              id="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" 
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('signInModal.passwordLabel')}</label>
            <input 
              type="password" 
              id="password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" 
              required
              autoComplete="current-password"
            />
          </div>
          <div className="pt-2">
             <button type="submit" className="w-full bg-brand-accent text-brand-text-on-accent font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 text-lg">
               {t('signInModal.button')}
             </button>
          </div>
          <p className="text-center text-sm text-brand-text-secondary">
            <Trans i18nKey="signInModal.switchToSignUp">
              Don't have an account?{' '}
              <button type="button" onClick={onSwitchToSignUp} className="font-semibold text-brand-accent hover:text-brand-accent-hover underline">
                Sign up now
              </button>
            </Trans>
          </p>
        </form>
      </div>
    </div>
  );
};