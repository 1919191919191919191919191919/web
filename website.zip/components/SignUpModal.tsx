import React, { useState, useMemo } from 'react';
import { User } from '../types';
import { Icon, XMarkIcon } from './Icon';
import { PasswordStrengthIndicator } from './PasswordStrengthIndicator';
import { useTranslation, Trans } from 'react-i18next';

interface SignUpModalProps {
  onClose: () => void;
  onSignUp: (user: User) => void;
  onSwitchToSignIn: () => void;
}

export const SignUpModal: React.FC<SignUpModalProps> = ({ onClose, onSignUp, onSwitchToSignIn }) => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const isPasswordStrong = useMemo(() => {
    const hasLength = password.length >= 8;
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return hasLength && hasUpper && hasLower && hasNumber && hasSpecial;
  }, [password]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isPasswordStrong) {
      alert('Please ensure your password meets all the security requirements.');
      return;
    }
    // Simulate successful sign-up
    onSignUp({ email });
  };

  return (
    <div 
        className="fixed inset-0 bg-brand-primary/70 backdrop-blur-sm z-50 flex justify-center items-center p-4 animate-modal-fade-in"
        onClick={onClose}
    >
      <div 
        className="bg-brand-secondary rounded-2xl shadow-2xl w-full max-w-md border border-overlay/10 animate-modal-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-overlay/10 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-brand-text">{t('signUpModal.title')}</h2>
          <button onClick={onClose} className="text-brand-text-secondary hover:text-brand-text p-1 rounded-full hover:bg-overlay/10">
            <Icon icon={XMarkIcon} className="w-6 h-6" />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div>
            <label htmlFor="signup-email" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('signUpModal.emailLabel')}</label>
            <input 
              type="email" 
              id="signup-email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" 
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label htmlFor="signup-password" className="block text-sm font-medium text-brand-text-secondary mb-2">{t('signUpModal.passwordLabel')}</label>
            <input 
              type="password" 
              id="signup-password" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              className="w-full bg-overlay/5 border border-overlay/10 rounded-lg p-3 text-brand-text focus:ring-2 focus:ring-brand-accent focus:border-brand-accent transition" 
              required
              autoComplete="new-password"
            />
          </div>
          <PasswordStrengthIndicator password={password} />
          <div className="pt-2">
             <button type="submit" disabled={!isPasswordStrong} className="w-full bg-brand-accent text-brand-text-on-accent font-bold py-3 px-6 rounded-lg hover:bg-brand-accent-hover transition-all duration-300 shadow-lg shadow-brand-accent/30 hover:shadow-glow hover:shadow-brand-accent/50 text-lg disabled:bg-gray-600 disabled:shadow-none disabled:cursor-not-allowed">
               {t('signUpModal.button')}
             </button>
          </div>
          <p className="text-center text-sm text-brand-text-secondary">
            <Trans i18nKey="signUpModal.switchToSignIn">
              Already have an account?{' '}
              <button type="button" onClick={onSwitchToSignIn} className="font-semibold text-brand-accent hover:text-brand-accent-hover underline">
                Sign in
              </button>
            </Trans>
          </p>
        </form>
      </div>
    </div>
  );
};