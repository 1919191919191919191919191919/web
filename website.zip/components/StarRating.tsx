
import React from 'react';
import { Icon, StarIcon } from './Icon';

interface StarRatingProps {
  rating: number;
  maxRating?: number;
  className?: string;
}

export const StarRating: React.FC<StarRatingProps> = ({ rating, maxRating = 5, className }) => {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 !== 0;
  const emptyStars = maxRating - fullStars - (halfStar ? 1 : 0);

  return (
    <div className={`flex items-center ${className}`}>
      {[...Array(fullStars)].map((_, i) => (
        <Icon key={`full-${i}`} icon={StarIcon} className="w-4 h-4 text-yellow-400" />
      ))}
      {/* Note: This example doesn't render half stars for simplicity, but could be extended */}
      {[...Array(emptyStars)].map((_, i) => (
        <Icon key={`empty-${i}`} icon={StarIcon} className="w-4 h-4 text-gray-600" />
      ))}
    </div>
  );
};
