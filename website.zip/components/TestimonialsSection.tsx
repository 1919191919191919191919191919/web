import React from 'react';
import { useTranslation } from 'react-i18next';
import { Icon, StarIcon } from './Icon';

const testimonials = [
  {
    name: 'GamerPro123',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026704d',
    rating: 5,
    review: "Absolutely game-changing. The Valorant suite is smooth, secure, and gave me the edge I needed. Support was also incredibly fast to respond to my questions. Highly recommend!",
    product: 'Valorant Suite'
  },
  {
    name: 'Shadow_Striker',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026705d',
    rating: 5,
    review: "The HWID Spoofer is a lifesaver. Worked perfectly and got me back into the game without any issues. The setup was surprisingly easy. A must-have tool for serious gamers.",
    product: 'HWID Spoofer Pro'
  },
  {
    name: 'COD_King',
    avatar: 'https://i.pravatar.cc/150?u=a042581f4e29026706d',
    rating: 4,
    review: "The Call of Duty suite is powerful. The ESP is clean and the anti-recoil is spot on. Had a few stutters initially but the latest update fixed it. Solid product.",
    product: 'Call of Duty Suite'
  }
];

const TestimonialCard: React.FC<typeof testimonials[0]> = ({ name, avatar, rating, review, product }) => {
  const { t } = useTranslation();
  return (
    <div className="bg-brand-secondary/50 border border-overlay/10 rounded-2xl p-6 flex flex-col h-full transform transition-all duration-300 hover:-translate-y-2 hover:shadow-glow hover:shadow-brand-accent/10">
      <div className="flex items-center mb-4">
        <img src={avatar} alt={name} className="w-12 h-12 rounded-full mr-4 border-2 border-brand-accent/50" />
        <div>
          <p className="font-bold text-brand-text">{name}</p>
          <p className="text-sm text-brand-text-secondary">{t('testimonials.purchased')}: {product}</p>
        </div>
      </div>
      <div className="flex mb-4">
        {[...Array(5)].map((_, i) => (
          <Icon key={i} icon={StarIcon} className={`w-5 h-5 ${i < rating ? 'text-yellow-400' : 'text-gray-600'}`} />
        ))}
      </div>
      <p className="text-brand-text-secondary flex-grow">"{review}"</p>
    </div>
  );
}

export const TestimonialsSection: React.FC = () => {
  const { t } = useTranslation();

  return (
    <section id="reviews-section" className="py-24 scroll-mt-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-black text-brand-text tracking-tighter leading-tight">
            {t('testimonials.title')}
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-lg text-brand-text-secondary">
            {t('testimonials.subtitle')}
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="opacity-0 animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
              <TestimonialCard {...testimonial} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};