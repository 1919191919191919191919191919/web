import React, { useState, useEffect, useRef } from 'react';
import { Icon, PaintBrushIcon } from './Icon';

interface ThemeSwitcherProps {
  theme: string;
  setTheme: (theme: string) => void;
}

const themes = [
  { name: 'indigo', color: '#4F46E5' },
  { name: 'yellow', color: '#FBBF24' },
  { name: 'light', color: '#E5E7EB' },
];

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ theme, setTheme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [dropdownRef]);

  const handleThemeChange = (themeName: string) => {
    setTheme(themeName);
    setIsOpen(false);
  }

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 text-sm font-medium text-brand-text-secondary hover:text-brand-text transition-colors p-2"
        aria-label="Change theme"
      >
        <Icon icon={PaintBrushIcon} className="w-5 h-5" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-auto bg-brand-secondary border border-overlay/10 rounded-lg shadow-2xl z-50 overflow-hidden animate-fade-in-up p-2" style={{animationDuration: '0.2s'}}>
          <div className="flex space-x-2">
            {themes.map((t) => (
              <button
                key={t.name}
                onClick={() => handleThemeChange(t.name)}
                aria-label={`Switch to ${t.name} theme`}
                className={`w-8 h-8 rounded-full transition-transform transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-brand-secondary focus:ring-overlay ${theme === t.name ? 'ring-2 ring-overlay' : ''}`}
                style={{ backgroundColor: t.color }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};