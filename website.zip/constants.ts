

import { Product, GameTemplate, GameCategory } from './types';

const NEW_VALORANT_IMAGE_URL = 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/valorant-hero-card.png';

export const GAME_CATEGORIES: GameCategory[] = [
  { id: 'cat_valorant', name: 'Valorant', group: 'Featured Products', imageUrl: NEW_VALORANT_IMAGE_URL },
  { id: 'cat_cod', name: 'Call of Duty', group: 'Featured Products', imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/cod.png' },
  { id: 'cat_fortnite', name: 'Fortnite', group: 'Featured Products', imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/fortnite.png' },
  { id: 'cat_rust', name: 'Rust', group: 'Featured Products', imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/rust.png' },
  { id: 'cat_rivals', name: 'Marvel Rivals', group: 'Featured Products', imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/rivals.png' },
  { id: 'cat_spoofer', name: 'HWID Spoofer', group: 'System Tools', imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/spoofer.png' },
];


export const INITIAL_PRODUCTS: Product[] = [
  // Valorant Products
  {
    id: 'prod_valorant_suite',
    name: 'Valorant Suite',
    category: 'Valorant',
    price: 49.99,
    description: 'Enhance your Valorant gameplay with our premium suite of tools. Gain a competitive edge with advanced features, including precise aim assistance, full-map awareness with wallhacks, and a customizable radar.',
    imageUrl: NEW_VALORANT_IMAGE_URL,
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.9,
    reviews: 742,
    stock: 'Unlimited',
  },
  {
    id: 'prod_valorant_aimbot',
    name: 'Valorant Aimbot',
    category: 'Valorant',
    price: 29.99,
    description: 'Get the competitive edge with our precision aimbot for Valorant. Features customizable FOV, smoothing, and bone selection.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/valorant_product_2.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.8,
    reviews: 412,
    stock: 'Unlimited',
  },
  // Call of Duty Products
  {
    id: 'prod_cod_suite',
    name: 'Call of Duty Suite',
    category: 'Call of Duty',
    price: 54.99,
    description: 'Dominate in Call of Duty with our undetected cheat suite. Features silent aim, player ESP, UAV, and advanced anti-recoil for ultimate accuracy.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/cod.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.8,
    reviews: 621,
    stock: 'Unlimited',
  },
  // Fortnite Products
  {
    id: 'prod_fortnite_suite',
    name: 'Fortnite Suite',
    category: 'Fortnite',
    price: 45.00,
    description: 'Become a Fortnite champion with our powerful enhancement tool. Includes aimbot, building helper, player ESP, and item detection to always stay ahead.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/fortnite.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.7,
    reviews: 559,
    stock: 'Unlimited',
  },
  // Rust Products
  {
    id: 'prod_rust_suite',
    name: 'Rust Suite',
    category: 'Rust',
    price: 39.99,
    description: 'Survive and thrive in Rust with our comprehensive toolkit. Features resource ESP, aim assistance, player highlighting, and debug camera for maximum map control.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/rust.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.8,
    reviews: 430,
    stock: 'Unlimited',
  },
  // Marvel Rivals Products
   {
    id: 'prod_rivals_suite',
    name: 'Marvel Rivals Suite',
    category: 'Marvel Rivals',
    price: 49.99,
    description: 'Unleash your power in Marvel Rivals with our specialized cheat. Includes ability cooldown reduction, player ESP, and predictive aimbot for hero-based combat.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/rivals.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 4.9,
    reviews: 290,
    stock: 'Unlimited',
  },
  // Spoofer Products
  {
    id: 'prod_spoofer_pro',
    name: 'HWID Spoofer Pro',
    category: 'HWID Spoofer',
    price: 29.99,
    description: 'Protect yourself from hardware bans in any game with our reliable HWID spoofer. Works on a system-level to ensure you stay undetected.',
    imageUrl: 'https://storage.googleapis.com/vairis-dev-public-assets/pre-canned/spoofer.png',
    seller: { name: 'Vairis', avatarUrl: 'https://picsum.photos/seed/seller-v/40/40', isVerified: true },
    rating: 5.0,
    reviews: 812,
    stock: 'Unlimited',
  },
];

export const GAME_TEMPLATES: GameTemplate[] = [
  {
    name: 'Valorant Cheat',
    category: 'Game Cheat',
    description: 'Advanced cheat for Valorant with aimbot, wallhack, and more.',
    imageUrl: 'https://picsum.photos/seed/valorant/600/400',
  },
  {
    name: 'Fortnite Aimbot',
    category: 'Game Cheat',
    description: 'Undetected aimbot for Fortnite. Win every game.',
    imageUrl: 'https://picsum.photos/seed/fortnite/600/400',
  },
  {
    name: 'Apex Legends ESP',
    category: 'Game Cheat',
    description: 'See enemies through walls with our powerful ESP for Apex Legends.',
    imageUrl: 'https://picsum.photos/seed/apex/600/400',
  },
  {
    name: 'League of Legends Script',
    category: 'Game Script',
    description: 'Automate combos and dodge skillshots with our LoL scripts.',
    imageUrl: 'https://picsum.photos/seed/lol/600/400',
  },
];