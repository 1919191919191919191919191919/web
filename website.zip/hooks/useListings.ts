

import { useState, useCallback } from 'react';
import { Product, GameCategory } from '../types';
import { INITIAL_PRODUCTS, GAME_CATEGORIES } from '../constants';

// A mock seller for new products created by admin
const ADMIN_SELLER = {
  name: 'Vairis Admin',
  avatarUrl: 'https://picsum.photos/seed/admin/40/40',
  isVerified: true,
};

export const useListings = () => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<GameCategory[]>(GAME_CATEGORIES);

  const addProduct = useCallback((productData: Omit<Product, 'id' | 'seller' | 'rating' | 'reviews'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod_${Date.now()}`,
      seller: ADMIN_SELLER,
      rating: parseFloat((Math.random() * 2 + 3).toFixed(1)), // Random rating between 3.0 and 5.0
      reviews: Math.floor(Math.random() * 100), // Random reviews
    };
    setProducts(prev => [newProduct, ...prev]);
  }, []);

  const updateProduct = useCallback((updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  }, []);

  const deleteProduct = useCallback((productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  }, []);

  const addCategory = useCallback((categoryData: Omit<GameCategory, 'id'>) => {
    const newCategory: GameCategory = {
      ...categoryData,
      id: `cat_${Date.now()}`,
    };
    setCategories(prev => [newCategory, ...prev]);
  }, []);

  const updateCategory = useCallback((updatedCategory: GameCategory) => {
    setCategories(prev => prev.map(c => c.id === updatedCategory.id ? updatedCategory : c));
  }, []);

  const deleteCategory = useCallback((categoryId: string) => {
    setCategories(prev => prev.filter(c => c.id !== categoryId));
  }, []);


  return { products, addProduct, updateProduct, deleteProduct, categories, addCategory, updateCategory, deleteCategory };
};