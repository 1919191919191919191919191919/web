import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import HttpBackend from 'i18next-http-backend';

i18n
  .use(HttpBackend) // Use http backend to load translation files
  .use(LanguageDetector) // Detect user language
  .use(initReactI18next) // Pass i18n instance to react-i18next
  .init({
    fallbackLng: 'en', // Use English if detected language is not available
    debug: false,
    interpolation: {
      escapeValue: false, // React already protects from xss
    },
    detection: {
      order: ['navigator', 'htmlTag', 'path', 'subdomain'],
      caches: ['localStorage', 'cookie'],
    },
    // configuration for i18next-http-backend
    backend: {
      loadPath: '/locales/{{lng}}/translation.json',
    },
  });

export default i18n;