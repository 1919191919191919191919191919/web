


export interface User {
  email: string;
  isAdmin?: boolean;
}

export interface Seller {
  name:string;
  avatarUrl: string;
  isVerified: boolean;
}

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  imageUrl: string;
  seller: Seller;
  rating: number;
  reviews: number;
  stock: number | 'Unlimited';
}

export interface CartItem extends Product {
  quantity: number;
}

export interface GameTemplate {
  name: string;
  category: string;
  description: string;
  imageUrl: string;
}

export interface GameCategory {
  id: string;
  name: string;
  group: string;
  imageUrl: string;
}

export interface NotificationData {
  productName: string;
  location: string;
  timestamp: Date;
  imageUrl: string;
}